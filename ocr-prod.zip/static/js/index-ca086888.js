import{S as Ro,V as So}from"./index-9e2d7108.js";function Io(on,xn){for(var rn=0;rn<xn.length;rn++){const z=xn[rn];if(typeof z!="string"&&!Array.isArray(z)){for(const U in z)if(U!=="default"&&!(U in on)){const M=Object.getOwnPropertyDescriptor(z,U);M&&Object.defineProperty(on,U,M.get?M:{enumerable:!0,get:()=>z[U]})}}}return Object.freeze(Object.defineProperty(on,Symbol.toStringTag,{value:"Module"}))}var vn={},Lo={get exports(){return vn},set exports(on){vn=on}};(function(on,xn){(function(rn,z){on.exports=z()})(So,function(){return(()=>{var rn={400:(M,H,D)=>{D.r(H),D.d(H,{GLHelper:()=>tn,glInstance:()=>Wn,ops:()=>Hn,webgl_types:()=>Tn});var Tn={};D.r(Tn),D.d(Tn,{UniformType:()=>B});var sn={};D.r(sn),D.d(sn,{exp_func:()=>lo,hardSigmoid:()=>io,leakyRelu:()=>oo,pow_func:()=>ao,prelu:()=>Jn,relu6:()=>no,scale:()=>eo,scaleWidthBias:()=>to,sigmoid:()=>ro,sqrt:()=>so,tanh_func:()=>uo,transferFromNHWCtoNCHW:()=>$n});var _n={};function On(){var t;if(typeof window<"u")t=window;else if(D.g!==void 0)t=D.g;else{if(typeof self>"u")throw new Error("Could not find a global object");t=self}return t}function Cn(t,n){var o=On();return o[t]||(o[t]=n),o[t]}D.r(_n),D.d(_n,{getPixelsFromTexturePos:()=>_o,getSamplerCode:()=>Bn,getTensorPosFromArrayIndex:()=>kn,getValueFromTensorPos:()=>fo,getValueFromTensorPosPacking:()=>co,moveTexture2PosToReal:()=>go});var en={opRegistry:{ops:{}},backend:"",backendInstance:null};en=Cn("GLOBALS",en);var Rn=On();Rn.ImageBitmap||(Rn.ImageBitmap=function(){});const R=Cn("env",new(function(){function t(){this.ENV={}}return t.prototype.set=function(n,o){this.ENV[n]=o},t.prototype.get=function(n){return this.ENV[n]},t}()));var B;(function(t){t.uniform1f="1f",t.uniform1fv="1fv",t.uniform1i="1i",t.uniform1iv="1iv",t.uniform2f="2f",t.uniform2fv="2fv",t.uniform2i="2i",t.uniform2iv="2iv",t.uniform3f="3f",t.uniform3fv="3fv",t.uniform3i="3i",t.uniform3iv="3iv",t.uniform4f="4f",t.uniform4fv="4fv",t.uniform4i="4i",t.uniform4iv="4iv"})(B||(B={}));var Z;function fn(t){for(var n=t.length,o=function(){for(var r=0,s=0,i=arguments.length;s<i;s++)r+=arguments[s].length;var a=Array(r),u=0;for(s=0;s<i;s++)for(var f=arguments[s],l=0,c=f.length;l<c;l++,u++)a[u]=f[l];return a}(t),e=[];n>1;)o.splice(0,1),e.push(o.reduce(function(r,s){return r*s})),n--;return e}function cn(t,n){if(t.length===1)return"float "+n+" = float("+t[0]+");";for(var o=t.length,e=`
        vec`+o+" "+n+" = vec"+o+`(
    `,r=0;r<o;r++)e+="float("+t[r]+"),";return e.slice(0,-1)+");"}function gn(t,n,o){if(t.length===0)return"";if(R.get("webglVersion")===2)return t.reduce(function(r,s,i){return r+(i<t.length-1?o+"("+s+"), ":o+"("+s+"));")},o+" "+n+"[] = "+o+"[](");var e=t.reduce(function(r,s,i){return r+`
            `+n+"["+i+"] = "+o+"("+s+");"},"");return`
        `+o+" "+n+"["+t.length+`];
        `+e+`
    `}function hn(t,n,o){if(t.length===0)return"";var e=t.reduce(function(r,s,i){return r+(i===0?`
            `+o+" res = "+o+`(0);
            if (index == `+i+`) {
                res = arr[`+i+`];
            }`:`
            else if (index == `+i+`) {
                res = arr[`+i+`];
            }`)},"");return`
    `+o+" getValueFromArrByIndex_"+n+"("+o+"["+t.length+`] arr, int index) {
        `+(R.get("webglVersion")===2?o+" res = arr[index];":e)+`
        return res;
    }
    `}(function(t){t.INT_TYPE="int",t.FLOAT_TYPE="float"})(Z||(Z={}));var dn,Sn;(function(t){t[t.VS_SHADER=0]="VS_SHADER",t[t.FS_SHADER=1]="FS_SHADER"})(dn||(dn={})),function(t){t[t.FLOAT_VEC2=35664]="FLOAT_VEC2",t[t.FLOAT_VEC3=35665]="FLOAT_VEC3",t[t.FLOAT_VEC4=35666]="FLOAT_VEC4",t[t.INT_VEC2=35667]="INT_VEC2",t[t.INT_VEC3=35668]="INT_VEC3",t[t.INT_VEC4=35669]="INT_VEC4",t[t.BOOL=35670]="BOOL",t[t.BOOL_VEC2=35671]="BOOL_VEC2",t[t.BOOL_VEC3=35672]="BOOL_VEC3",t[t.BOOL_VEC4=35673]="BOOL_VEC4",t[t.FLOAT_MAT2=35674]="FLOAT_MAT2",t[t.FLOAT_MAT3=35675]="FLOAT_MAT3",t[t.FLOAT_MAT4=35676]="FLOAT_MAT4",t[t.SAMPLER_2D=35677]="SAMPLER_2D",t[t.SAMPLER_CUBE=35678]="SAMPLER_CUBE",t[t.FLOAT=5126]="FLOAT",t[t.INT=5124]="INT"}(Sn||(Sn={}));var In,Yn=function(t,n,o){this.size=t,this.type=n,this.location=o},qn=function(t,n,o){this.size=t,this.type=n,this.location=o},tn=function(){function t(){}return t.getWebglVersion=function(){return R.get("webglVersion")},t.createCanvas=function(){return R.get("canvas")||document&&document.createElement("canvas")},t.setWebglVersion=function(n){R.set("webglVersion",n)},t.setWebGLRenderingContext=function(n){return this.gl=n,n},t.getWebGLRenderingContext=function(){return this.gl?this.gl:this.createWebGLRenderingContext()},t.createWebGLRenderingContext=function(){if(this.gl)return this.gl;var n=this.createCanvas();if(!n)return null;n.addEventListener&&n.addEventListener("webglcontextlost",function(e){throw e.preventDefault(),Error("webgl context is lost~")},!1);var o=n.getContext("webgl2",this.WEBGL_ATTRIBUTES);return o?R.set("webglVersion",2):(R.set("webglVersion",1),o=n.getContext("webgl",this.WEBGL_ATTRIBUTES)||n.getContext("experimental-webgl",this.WEBGL_ATTRIBUTES)),o},t.printStates=function(n){console.log("1. isBlendEnable = "+n.isEnabled(n.BLEND)),console.log("2. isCullFaceEnable = "+n.isEnabled(n.CULL_FACE)),console.log("3. isDepthTestEnable = "+n.isEnabled(n.DEPTH_TEST)),console.log("4. isDitherEnable = "+n.isEnabled(n.DITHER)),console.log("5. isPolygonOffsetFillEnable = "+n.isEnabled(n.POLYGON_OFFSET_FILL)),console.log("6. isSampleAlphtToCoverageEnable = "+n.isEnabled(n.SAMPLE_ALPHA_TO_COVERAGE)),console.log("7. isSampleCoverageEnable = "+n.isEnabled(n.SAMPLE_COVERAGE)),console.log("8. isScissorTestEnable = "+n.isEnabled(n.SCISSOR_TEST)),console.log("9. isStencilTestEnable = "+n.isEnabled(n.STENCIL_TEST))},t.printWebGLInfo=function(n){console.log("renderer = "+n.getParameter(n.RENDERER)),console.log("version = "+n.getParameter(n.VERSION)),console.log("vendor = "+n.getParameter(n.VENDOR)),console.log("glsl version = "+n.getParameter(n.SHADING_LANGUAGE_VERSION))},t.printWebGLTextureInfo=function(n){console.log("MAX_COMBINED_TEXTURE_IMAGE_UNITS = ",n.getParameter(n.MAX_COMBINED_TEXTURE_IMAGE_UNITS)),console.log("MAX_TEXTURE_IMAGE_UNITS = ",n.getParameter(n.MAX_TEXTURE_IMAGE_UNITS)),console.log("MAX_TEXTURE_SIZE = ",n.getParameter(n.MAX_TEXTURE_SIZE)),console.log("MAX_CUBE_MAP_TEXTURE_SIZE = ",n.getParameter(n.MAX_CUBE_MAP_TEXTURE_SIZE))},t.triggerContextLostEvent=function(n){var o=n.getExtension("WEBGL_lose_context");o!==null&&o.loseContext()},t.checkGLError=function(n){var o=n.getError();return o!==0&&(console.log("WebGL Error NO: ",o),!0)},t.setDefaultState=function(n){n.clearColor(0,0,0,0),n.clearDepth(1),n.enable(n.DEPTH_TEST),n.enable(n.CULL_FACE),n.enable(n.SCISSOR_TEST)},t.setViewport=function(n,o){n.viewport(o[0],o[1],o[2],o[3])},t.initShader=function(n,o,e){var r=this.createShader(n,o);return this.compileShader(n,e,r),r},t.createShader=function(n,o){var e;if((e=o===dn.VS_SHADER?n.createShader(n.VERTEX_SHADER):n.createShader(n.FRAGMENT_SHADER))===null)throw new Error("WebGLShader创建失败！");return e},t.compileShader=function(n,o,e){return n.shaderSource(e,o),n.compileShader(e),n.getShaderParameter(e,n.COMPILE_STATUS)!==!1||(console.error(n.getShaderInfoLog(e)),n.deleteShader(e),!1)},t.createProgram=function(n){var o=n.createProgram();if(o===null)throw new Error("WebGLProgram创建失败！");return o},t.linkProgram=function(n,o,e,r,s,i){return s===void 0&&(s=null),i===void 0&&(i=null),n.attachShader(o,e),n.attachShader(o,r),s!==null&&s(n,o),n.linkProgram(o),n.getProgramParameter(o,n.LINK_STATUS)===!1?(console.error(n.getProgramInfoLog(o)),n.deleteShader(e),n.deleteShader(r),n.deleteProgram(o),!1):(n.validateProgram(o),n.getProgramParameter(o,n.VALIDATE_STATUS)===!1?(console.error(n.getProgramInfoLog(o)),n.deleteShader(e),n.deleteShader(r),n.deleteProgram(o),!1):(i!==null&&i(n,o),!0))},t.getProgramActiveAttribs=function(n,o,e){for(var r=n.getProgramParameter(o,n.ACTIVE_ATTRIBUTES),s=0;s<r;s++){var i=n.getActiveAttrib(o,s);i&&(e[i.name]=new qn(i.size,i.type,n.getAttribLocation(o,i.name)))}},t.getProgramAtciveUniforms=function(n,o,e){for(var r=n.getProgramParameter(o,n.ACTIVE_UNIFORMS),s=0;s<r;s++){var i=n.getActiveUniform(o,s);if(i){var a=n.getUniformLocation(o,i.name);a!==null&&(e[i.name]=new Yn(i.size,i.type,a))}}},t.createBuffer=function(n){var o=n.createBuffer();if(o===null)throw new Error("WebGLBuffer创建失败！");return o},t.getColorBufferData=function(n){var o=new Uint8Array(n.drawingBufferWidth*n.drawingBufferHeight*4);return n.readPixels(0,0,n.drawingBufferWidth,n.drawingBufferHeight,n.RGBA,n.UNSIGNED_BYTE,o),o},t.setUniformParam=function(n,o,e,r){switch(e){case B.uniform1f:n.uniform1f(o,r);break;case B.uniform1fv:n.uniform1fv(o,r);break;case B.uniform1i:n.uniform1i(o,r);break;case B.uniform1iv:n.uniform1iv(o,r);break;case B.uniform2f:n.uniform2f(o,r[0],r[1]);break;case B.uniform2fv:n.uniform2fv(o,r);break;case B.uniform2i:n.uniform2i(o,r[0],r[1]);break;case B.uniform2iv:n.uniform2iv(o,r);break;case B.uniform3f:n.uniform3f(o,r[0],r[1],r[2]);break;case B.uniform3fv:n.uniform3fv(o,r);break;case B.uniform3i:n.uniform3i(o,r[0],r[1],r[2]);break;case B.uniform3iv:n.uniform3iv(o,r);break;case B.uniform4f:n.uniform4f(o,r[0],r[1],r[2],r[3]);break;case B.uniform4fv:n.uniform4fv(o,r);break;case B.uniform4i:n.uniform4i(o,r[0],r[1],r[2],r[3]);break;case B.uniform4iv:n.uniform4iv(o,r);break;default:console.error("["+e+"]: unknown uniform type")}},t.genTextureInfoFromTensorShape=function(n,o){var e=n||4096,r=o.shape,s=r===void 0?[]:r,i=s[0],a=s[1],u=s[2],f=s[3];if(i*u<=e&&a*f<=e)o.shape_texture=[i*u,a*f];else{var l=function(){for(var T=0,v=0,E=arguments.length;v<E;v++)T+=arguments[v].length;var A=Array(T),p=0;for(v=0;v<E;v++)for(var x=arguments[v],y=0,F=x.length;y<F;y++,p++)A[p]=x[y];return A}(s).sort(function(T,v){return T-v}),c=l[0],g=l[1],d=l[2],_=c*l[3],h=g*d;if(_>e||h>e){var m=[_,h].sort(function(T,v){return T-v}),b=m[0],P=m[1],V=function(T,v){var E=v;if(T%E==0)return E;for(;E<T&&T%E!=0;)E++;return E}(P,Math.ceil(P/e));if(_=b*V,h=Math.ceil(P/V),R.get("debug")&&console.error("大小超限",s,[h,_]),_>e||h>e)throw new Error("Requested texture size ["+_+"x"+h+"] greater than WebGL maximum on this browser / GPU ["+e+"x"+e+"].")}o.shape_texture=[h,_]}},t.WEBGL_ATTRIBUTES={alpha:!1,antialias:!1,premultipliedAlpha:!1,preserveDrawingBuffer:!1,depth:!1,stencil:!1,failIfMajorPerformanceCaveat:!0,powerPreference:"high-performance"},t.gl=null,t}();(function(t){t[t.GL_REPEAT=0]="GL_REPEAT",t[t.GL_MIRRORED_REPEAT=1]="GL_MIRRORED_REPEAT",t[t.GL_CLAMP_TO_EDGE=2]="GL_CLAMP_TO_EDGE"})(In||(In={}));var Fn=function(){function t(){}return t.getTextureConfig=function(n){var o,e,r,s,i,a,u,f,l=n,c=!0,g=!0;return R.get("webglVersion")===2?(o=l.getExtension("EXT_color_buffer_float"),r=l.HALF_FLOAT,s=l.R32F,i=l.RGBA32F,a=l.R16F,u=l.RGBA16F,e=l.RED,f=l.RGBA32F):(s=l.RGBA,a=l.RGBA,u=l.RGBA,i=l.RGBA,e=l.RGBA,f=l.RGBA,o=l.getExtension("OES_texture_float"),r=l.getExtension("OES_texture_half_float").HALF_FLOAT_OES,c=this.isDownloadFloatTextureEnabled(l,f),g=this.isFloatTextureReadPixelsEnabledMethod(l,1,c)),{textureFloat:o,textureHalfFloat:r,internalFormat:s,internalFormatPacked:i,internalFormatHalfFloat:a,internalFormatPackedHalfFloat:u,textureFormat:e,downloadInternalFormat:f,frameBufferSupportFloat:c,isFloatTextureReadPixelsEnabled:g}},t.isFloatTextureReadPixelsEnabledMethod=function(n,o,e){var r=n;if(o===0)return!1;if(o===1){if(r.getExtension("OES_texture_float")==null)return!1}else if(r.getExtension("EXT_color_buffer_float")==null||r.getExtension("EXT_color_buffer_half_float")==null)return!1;var s=r.createFramebuffer(),i=r.createTexture();r.bindTexture(r.TEXTURE_2D,i);var a=o===2?r.RGBA32F:r.RGBA;r.texImage2D(r.TEXTURE_2D,0,a,1,1,0,r.RGBA,e?r.FLOAT:r.getExtension("OES_texture_half_float").HALF_FLOAT_OES,null),r.bindFramebuffer(r.FRAMEBUFFER,s),r.framebufferTexture2D(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,i,0);var u=r.checkFramebufferStatus(r.FRAMEBUFFER)===r.FRAMEBUFFER_COMPLETE;r.readPixels(0,0,1,1,r.RGBA,r.FLOAT,new Float32Array(4));var f=r.getError()===r.NO_ERROR;return u&&f},t.isDownloadFloatTextureEnabled=function(n,o){var e=n.createTexture();n.bindTexture(n.TEXTURE_2D,e),n.texImage2D(n.TEXTURE_2D,0,o,1,1,0,n.RGBA,n.FLOAT,null);var r=n.createFramebuffer();n.bindFramebuffer(n.FRAMEBUFFER,r),n.framebufferTexture2D(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,e,0);var s=n.checkFramebufferStatus(n.FRAMEBUFFER)===n.FRAMEBUFFER_COMPLETE;return n.bindTexture(n.TEXTURE_2D,null),n.bindFramebuffer(n.FRAMEBUFFER,null),n.deleteTexture(e),n.deleteFramebuffer(r),s},t.uploadDataToTexture=function(n,o,e,r){n.texParameteri(n.TEXTURE_2D,n.TEXTURE_MAG_FILTER,n.NEAREST),n.texParameteri(n.TEXTURE_2D,n.TEXTURE_MIN_FILTER,n.NEAREST),n.texParameteri(n.TEXTURE_2D,n.TEXTURE_WRAP_S,n.CLAMP_TO_EDGE),n.texParameteri(n.TEXTURE_2D,n.TEXTURE_WRAP_T,n.CLAMP_TO_EDGE);var s=e.width_texture,i=e.height_texture,a=e.data,u=n.RGBA,f=n.RGBA,l=n.FLOAT,c=a;if(a instanceof Uint8Array||a instanceof Uint8ClampedArray)l=n.UNSIGNED_BYTE;else{if(!(a instanceof Float32Array||a instanceof Array))return void n.texImage2D(n.TEXTURE_2D,0,n.RGBA,n.RGBA,n.UNSIGNED_BYTE,a);if(R.get("webglVersion")===2){var g=R.get("webgl_force_half_float_texture");u=r?g?o.internalFormatPackedHalfFloat:o.internalFormatPacked:g?o.internalFormatHalfFloat:o.internalFormat,f=r?n.RGBA:o.textureFormat}else{for(var d=new Float32Array(s*i*4),_=0;_<a.length;_++)r?d[_]=a[_]:(d[4*_]=a[_],d[4*_+1]=0,d[4*_+2]=0,d[4*_+3]=0);c=d}}n.texImage2D(n.TEXTURE_2D,0,u,s,i,0,f,l,c)},t.genOutputTexture=function(n,o,e,r){var s=e.interpType,i=e.width_texture,a=e.height_texture,u=n.createTexture();n.bindTexture(n.TEXTURE_2D,u),n.texParameteri(n.TEXTURE_2D,n.TEXTURE_MAG_FILTER,s==="LINEAR"?n.LINEAR:n.NEAREST),n.texParameteri(n.TEXTURE_2D,n.TEXTURE_MIN_FILTER,s==="LINEAR"?n.LINEAR:n.NEAREST),n.texParameteri(n.TEXTURE_2D,n.TEXTURE_WRAP_S,n.CLAMP_TO_EDGE),n.texParameteri(n.TEXTURE_2D,n.TEXTURE_WRAP_T,n.CLAMP_TO_EDGE);var f=R.get("webgl_force_half_float_texture"),l=f?o.internalFormatPackedHalfFloat:o.internalFormatPacked,c=R.get("webglVersion")===2?f?n.HALF_FLOAT:n.FLOAT:o.frameBufferSupportFloat?n.FLOAT:o.textureHalfFloat,g=r?o.isFloatTextureReadPixelsEnabled?c:n.UNSIGNED_BYTE:null;return n.texImage2D(n.TEXTURE_2D,0,l,i,a,0,n.RGBA,r?g:c,null),n.bindTexture(n.TEXTURE_2D,null),u},t}(),Zn=[`
    precision highp float;
    precision highp int;

    attribute vec4 position;
    varying vec2 vCoord;

    void main() {
        vCoord.x = (position.x + 1.0) / 2.0;
        vCoord.y = (position.y + 1.0) / 2.0;
        gl_Position = position;
    }
    `,`#version 300 es
    in vec4 position;
    out vec2 vCoord;

    void main() {
        vCoord.x = (position.x + 1.0) / 2.0;
        vCoord.y = (position.y + 1.0) / 2.0;
        gl_Position = position;
    }
    `],Kn=new Float32Array([-1,1,-1,-1,1,1,1,-1]),Qn=["length_shape","length_unformatted_shape","width_shape","height_shape","width_texture","height_texture","offset_x","offset_y","channel","total_shape","numbers_shape"],Ln={float:["multi_value","bias_value"],bool:["fuse_relu"]};function pn(){return`
    `+(R.get("useModAdaptor")?`
            int calMod(int a, int b) {
                float modV = mod(float(a), float(b));
                if (modV == float(b)) {
                    modV = 0.0;
                }
                return int(modV);
            }
        `:`
            int calMod(int a, int b) {
                return a - a / b * b;
            }
        `)+`
    `+(R.get("useDivisionAdaptor")?`
            int calDivision(int a, int b) {
                return int(float(a) / (float(b) - 0.0001));
            }
        `:`
            int calDivision(int a, int b) {
                return a / b;
            }
        `)+`
    
    float tanh_calc(float num) {
        float res = (exp(2.0 * num) - 1.0) / (exp(2.0 * num) + 1.0);
        return res;
    }
    
    `}const $n=`
ivec4 transferFromNHWCtoNCHW(
    int sumVal,
    const int channel,
    const int width_shape,
    const int height_shape,
    const int total_shape) {

    int n_origin = int(total_shape/(channel * width_shape * height_shape));
    int new_a = calMod(sumVal, width_shape);
    sumVal = int((sumVal - new_a) / width_shape);
    int new_b = calMod(sumVal, height_shape);
    sumVal = int((sumVal - new_b) / height_shape);
    int new_g = calMod(sumVal, channel);
    sumVal = int((sumVal - new_g) / channel);
    int new_r = calMod(sumVal, n_origin);
    return ivec4(new_r,new_g,new_b,new_a);
}
`;var Jn=`
float prelu(float x, float p, float b) {
    float result = x;
    if (x < 0.0) {
        result = x * p;
    }

    return result;
}`,no=`
float relu6(float x, float threshold, float b) {
    float result = min(max(0.0, x), threshold);
    return result;
}`,oo=`
float leakyRelu(float x, float p, float b) {
    float result = max(x, x * p);
    return result;
}`,eo=`
float scale(float x, float p, float b) {
    float result = p * x + b;
    return result;
}`,to=`
float scaleWidthBias(float x, float p, float b) {
    float result = p * (x + b);
    return result;
}`,ro=`
float sigmoid(float x, float y, float z) {
    float result = 1.0 / (1.0 + exp(-x));
    return result;
}`,io=`
    float hardSigmoid(float x, float slope, float offset) {
        float result = max(0.0, min(1.0, slope * x + offset));
        return result;
    }
`,so=`
    float sqrt(float x, float slope, float offset) {
        return sqrt(x);
    }
`,ao=`
    float pow_func(float x, float factor, float offset) {
        return pow(x, factor);
    }
`,uo=`
float tanh_func(float x, float y, float z) {
    return tanh_calc(x);
}`,lo=`
float exp_func(float x, float y, float z) {
    float result = exp(x);
    return result;
}`;function fo(t,n){var o=n.width_shape,e=n.height_shape,r=n.channel,s=n.width_texture;return`
    float getValueFromTensorPos_`+t+`(int n, int c, int h, int w) {
        int index = n * `+o*e*r+" + c * "+o*e+" + h * "+o+` + w;
        // 0.01 hack: 在 PC/WISE 机器上，出现某个值（比如 index 为 3520） float(index) 和 float(3520) 返回值不同的情况，目前 +0.01 hack
        int pos_w = int(mod(float(index) + 0.01, float(`+s+`)));
        int pos_h = index / int(`+s+`);
        vec4 pixels = TEXTURE2D(texture_`+t+`,
            vec2(
                (float(pos_w)  + 0.5) / float(`+s+`),
                (float(pos_h) + 0.5) / float(`+n.height_texture+`)
            )
        );
        return pixels.r;
    }`}function co(t,n){var o=n.channel,e=n.height_shape,r=n.width_texture,s=n.height_texture,i=n.width_shape;return`
    vec4 getValueFromTensorPosPacking_`+t+`(int n, int c, int h, int w) {
        int index = n * `+i*e*o+" + c * "+i*e+" + h * "+i+` + w;
        // 0.01 hack: 在 PC/WISE 设备上，出现某个值（比如 index 为 3520） float(index) 和 float(3520) 返回值不同的情况，目前 +0.01 hack
        int pos_w = int(mod(float(index) + 0.01, float(`+r+`)));
        int pos_h = index / int(`+r+`);
        vec4 pixels = TEXTURE2D(texture_`+t+`,
            vec2(
                (float(pos_w)  + 0.5) / float(`+r+`),
                (float(pos_h) + 0.5) / float(`+s+`)
            )
        );
        return pixels;
    }`}function kn(t,n){var o=n.numbers_shape,e=n.length_shape;if(e===1)return`
            int getTensorPosFromArrayIndex_`+t+`(int n) {
                return calMod(n, `+o[0]+`);
            }
        `;for(var r="ivec"+e+"("+o.join(", ")+")",s="pos[0] = n / "+o[0]+";",i=1;i<e;i++)s+=`
            n = calMod(n, `+o[i-1]+`);
            pos[`+i+"] = calDivision(n, "+o[i]+`);
        `;return`
    ivec`+e+" shapeVec_"+t+" = "+r+`;
    ivec`+e+" getTensorPosFromArrayIndex_"+t+`(int n) {
        ivec`+e+` pos;
        `+s+`
        return pos;
    }
    `}function _o(t){return`
    #define getPixelsFromTexturePos_`+t+"(pos) TEXTURE2D(texture_"+t+`, pos)
    `}function go(t,n){return`
    vec2 moveTexture2PosToReal_`+t+`(vec2 v) {
        vec2 v2;
        v2.x = v.x * float(`+n.width_texture+`);
        v2.y = v.y * float(`+n.height_texture+`);
        return v2;
    }
    `}function Bn(t){return"uniform sampler2D texture_"+t+";"}function ho(t,n,o,e,r){var s,i,a="",u=n.name,f=n.mainFunc,l=n.textureFuncConf,c=l===void 0?{}:l,g=n.commonFuncConf;try{var d=function(p,x,y){for(var F={},w=Object.assign({},x),O=[],S=0,I=p;S<I.length;S++){for(var L=I[S],C=L.name,N={},X=0,G=Qn;X<G.length;X++)L[W=G[X]]!==void 0&&(N[W]=L[W]);F[C]=N,O.push(C)}for(var k=0,j=Object.keys(Ln);k<j.length;k++)for(var an=j[k],nn=0,K=Ln[an];nn<K.length;nn++){var W;x[W=K[nn]]!==void 0&&(w[W]=an+"("+x[W]+")")}return x.active_function&&(w.active_function=x.active_function),w.runtime=y,{textureParams:F,opParams:w,active_function:x.active_function}}(o,e,r),_=d.textureParams,h=d.opParams,m=d.active_function,b=R.get("webglVersion")===2?` #version 300 es
            #ifdef GL_FRAGMENT_PRECISION_HIGH
            precision highp float;
            precision highp int;
        #else
            precision mediump float;
            precision mediump int;
        #endif      
        `:` #ifdef GL_FRAGMENT_PRECISION_HIGH
            precision highp float;
            precision highp int;
        #else
            precision highp float;
            precision highp int;
        #endif
        `,P=function(p){var x=p.frameBufferSupportFloat,y=p.isFinalOp,F=p.isFloatTextureReadPixelsEnabled;return R.get("webglVersion")===2?`
        // 顶点shader透传的材质坐标
        in vec2 vCoord;
        out vec4 outColor;
        void setOutput(float result) {
            result = fuse_op(result);
            outColor.r = result;
        }
        void setPackedOutput(vec4 result) {
            outColor = result;
        }
        int calCeil(int a, int b) {
            return int(ceil(float(a) / float(b)));
        }
        `+pn()+`
    `:x?`
            varying vec2 vCoord;
            varying vec4 outColor;
            void setOutput(float result) {
                result = fuse_op(result);
                gl_FragColor.r = result;
            }
            void setPackedOutput(vec4 result) {
                gl_FragColor = result;
            }
            int calCeil(int a, int b) {
                return int(ceil(float(a) / float(b)));
            }
            `+pn()+`
    `:y&&!F?`
        varying vec2 vCoord;
        varying vec4 outColor;

        const float FLOAT_MAX = 1.70141184e38;
        const float FLOAT_MIN = 1.17549435e-38;

        #define isnan(value) isnan_custom(value)
        bool isnan_custom(float val) {
            return (val > 0. || val < 1. || val == 0.) ? false : true;
        }

        `+pn()+`

        int calCeil(int a, int b) {
            return int(ceil(float(a) / float(b)));
        }

        lowp vec4 encode_float(highp float v) {
            if (isnan(v)) {
            return vec4(255, 255, 255, 255);
            }

            highp float av = abs(v);

            if(av < FLOAT_MIN) {
            return vec4(0.0, 0.0, 0.0, 0.0);
            } else if(v > FLOAT_MAX) {
            return vec4(0.0, 0.0, 128.0, 127.0) / 255.0;
            } else if(v < -FLOAT_MAX) {
            return vec4(0.0, 0.0,  128.0, 255.0) / 255.0;
            }

            highp vec4 c = vec4(0,0,0,0);

            highp float e = floor(log2(av));
            highp float m = exp2(fract(log2(av))) - 1.0;

            c[2] = floor(128.0 * m);
            m -= c[2] / 128.0;
            c[1] = floor(32768.0 * m);
            m -= c[1] / 32768.0;
            c[0] = floor(8388608.0 * m);

            highp float ebias = e + 127.0;
            c[3] = floor(ebias / 2.0);
            ebias -= c[3] * 2.0;
            c[2] += floor(ebias) * 128.0;

            c[3] += 128.0 * step(0.0, -v);

            return c / 255.0;
        }

        void setOutput(float result) {
                result = fuse_op(result);
                gl_FragColor = encode_float(result);
        }
        `:`
            #define isnan(value) isnan_custom(value)
            bool isnan_custom(float val) {
                return (val > 0. || val < 1. || val == 0.) ? false : true;
            }

            varying vec2 vCoord;
            varying vec4 outColor;
            void setOutput(float result) {
                result = fuse_op(result);
                if(isnan(result)) {
                    gl_FragColor.r = 0.0;
                }else {
                    gl_FragColor.r = result;
                }
            }

            void setPackedOutput(vec4 result) {
                gl_FragColor = result;
            }

            `+pn()+`

            int calCeil(int a, int b) {
                return int(ceil(float(a) / float(b)));
            }
        `}(t),V=function(p){var x="",y="";if(p.fuse_opt)for(var F in p.fuse_opt){var w=F,O=0,S=0;switch(F){case"scale":var I=p.fuse_opt.scale.bias_after_scale;O=(C=p.fuse_opt.scale.scale)!==void 0?C:1,S=p.fuse_opt.scale.bias||0,I===!1&&I!==void 0&&(w="scaleWidthBias");break;case"relu":w="prelu";break;case"relu6":O=p.fuse_opt[F].threshold;break;case"hard_sigmoid":w="hardSigmoid",O=p.fuse_opt[F].slope||.2,S=p.fuse_opt[F].offset||.5;break;case"leakyRelu":O=p.fuse_opt[F].alpha;break;case"pow":w="pow_func",O=p.fuse_opt[F].factor||2;break;case"tanh":w="tanh_func";break;case"exp":w="exp_func"}if(F==="hard_swish"){var L=p.fuse_opt.hard_swish.offset!==void 0?p.fuse_opt.hard_swish.offset:3,C=p.fuse_opt.hard_swish.scale!==void 0?p.fuse_opt.hard_swish.scale:6;y+="res = res * min(max(0.0, res + float("+L+")), float("+(p.fuse_opt.hard_swish.threshold!==void 0?p.fuse_opt.hard_swish.threshold:6)+")) / float("+C+");"}else F==="dropout"?y+=`
                if (`+(p.fuse_opt.dropout.dropout_implementation==="downgrade_in_infer")+`) {
                    res = res * (1.0 - float(`+p.fuse_opt.dropout.dropout_prob+`));
                }`:(x+=sn[w],y+="res = "+w+"(res, float("+O+"), float("+S+"));")}return`
        `+x+`
        
        float fuse_op(float x) {
            float res = x;
            `+y+`
            return res;
        }
    `}(h),T=function(p,x,y,F){if(!p)return"";var w=Object.assign({},p);w["@all"]&&function(k,j){var an=j.filter(function(K){return K.name!=="out"}),nn=k["@all"];an.forEach(function(K){var W=K.name;k[W]?k[W].concat(nn):k[W]=nn}),delete k["@all"]}(w,F);for(var O="",S="",I=0,L=Object.keys(w);I<L.length;I++){var C=L[I];if(x[C]){S+=Bn(C);for(var N=0,X=w[C];N<X.length;N++){var G=X[N];if(_n[G])try{O+=_n[G](C,x[C],y)}catch(k){console.error(k)}}}}return`
    `+S+`
    `+O+`
    `}(c,_,h,o),v=function(p){return p===void 0?"":`
        int layer_run_time = `+p+`;
    `}(r),E=function(p){var x,y,F,w,O;return`
        
    vec2 _2d_shape_texture_out = vec2(float(`+p.width_texture+"), float("+p.height_texture+`));
    
        `+(y=(x=p).height_shape,F=x.width_shape,`
    ivec4 getOutputTensorPos() {
        vec2 outCoord = vCoord.xy * (_2d_shape_texture_out);
        int index = int(outCoord.x) + int(outCoord.y) * int(`+x.width_texture+`);

        int n1 = int(index / `+(w=F*y*x.channel)+`);
        int c1 = int(calMod(index, `+w+") / "+(O=F*y)+`);
        int h1 = int(calMod(index, `+O+") / "+F+`);
        int w1 = calMod(index, `+F+`);
        return ivec4(n1, c1, h1, w1);
    }
    
    `)}(_.out),A=function(p){if(!p)return"";for(var x="",y=0,F=p;y<F.length;y++){var w=F[y];sn[w]&&(x+=sn[w])}return x}(g);s=a=" "+b+`
            `+V+`
            `+P+`
            `+A+`
            `+(m?sn[m]:"")+`
            `+T+`
            `+v+`
            `+E+`
            `+f(_,h)+`
        `,i=R.get("webglVersion")===1?"texture2D":"texture",a=s.replace(/\bTEXTURE2D\b/g,i)}catch(p){console.error("["+u+"]: "+p)}return a}const po=function(){function t(n,o,e,r){var s=n;this.vShader=o;try{this.fShader=this.initShader(s,e,"fragment"),this.shape=r&&r.shape;var i=this.program=s.createProgram();s.attachShader(i,this.vShader),s.attachShader(i,this.fShader),s.linkProgram(i)}catch(a){throw new Error(a)}}return t.prototype.initShader=function(n,o,e){e===void 0&&(e="vertex");var r,s=e==="vertex"?n.VERTEX_SHADER:n.FRAGMENT_SHADER;if(e==="vertex"&&this.vShader)r=this.vShader;else if(r=n.createShader(s),e==="vertex"&&(this.vShader=r),n.shaderSource(r,o),n.compileShader(r),!n.getShaderParameter(r,n.COMPILE_STATUS))throw new Error("compile: "+n.getShaderInfoLog(r));return r},t.prototype.setProgram=function(n,o,e){n.useProgram(this.program),e||this.runVertexShader(n,o)},t.prototype.runVertexShader=function(n,o){var e=n.getAttribLocation(this.program,"position");n.enableVertexAttribArray(e),n.bindBuffer(n.ARRAY_BUFFER,o),n.vertexAttribPointer(e,2,n.FLOAT,!1,0,0)},t.Sampler="uSampler",t}();var bn,mo=(bn=function(t,n){return(bn=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(o,e){o.__proto__=e}||function(o,e){for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(o[r]=e[r])})(t,n)},function(t,n){function o(){this.constructor=t}bn(t,n),t.prototype=n===null?Object.create(n):(o.prototype=n.prototype,new o)}),yn=function(t,n,o,e){return new(o||(o=Promise))(function(r,s){function i(f){try{u(e.next(f))}catch(l){s(l)}}function a(f){try{u(e.throw(f))}catch(l){s(l)}}function u(f){var l;f.done?r(f.value):(l=f.value,l instanceof o?l:new o(function(c){c(l)})).then(i,a)}u((e=e.apply(t,n||[])).next())})},En=function(t,n){var o,e,r,s,i={label:0,sent:function(){if(1&r[0])throw r[1];return r[1]},trys:[],ops:[]};return s={next:a(0),throw:a(1),return:a(2)},typeof Symbol=="function"&&(s[Symbol.iterator]=function(){return this}),s;function a(u){return function(f){return function(l){if(o)throw new TypeError("Generator is already executing.");for(;i;)try{if(o=1,e&&(r=2&l[0]?e.return:l[0]?e.throw||((r=e.return)&&r.call(e),0):e.next)&&!(r=r.call(e,l[1])).done)return r;switch(e=0,r&&(l=[2&l[0],r.value]),l[0]){case 0:case 1:r=l;break;case 4:return i.label++,{value:l[1],done:!1};case 5:i.label++,e=l[1],l=[0];continue;case 7:l=i.ops.pop(),i.trys.pop();continue;default:if(!((r=(r=i.trys).length>0&&r[r.length-1])||l[0]!==6&&l[0]!==2)){i=0;continue}if(l[0]===3&&(!r||l[1]>r[0]&&l[1]<r[3])){i.label=l[1];break}if(l[0]===6&&i.label<r[1]){i.label=r[1],r=l;break}if(r&&i.label<r[2]){i.label=r[2],i.ops.push(l);break}r[2]&&i.ops.pop(),i.trys.pop();continue}l=n.call(t,i)}catch(c){l=[6,c],e=0}finally{o=r=0}if(5&l[0])throw l[1];return{value:l[0]?l[1]:void 0,done:!0}}([u,f])}}};const Po=function(t){function n(){var o=t.call(this)||this;return o.cacheTextures={},o.uniformLocations={},o.texturesMap={},o.queryList=[],o.currentTexture=null,o.width_shape_out=1,o.height_shape_out=1,o.width_texture_out=1,o.height_texture_out=1,o.channel=0,o.total_shape=0,o}return mo(n,t),n.prototype.init=function(){return yn(this,void 0,void 0,function(){var o;return En(this,function(e){return o=this.gl=tn.createWebGLRenderingContext(),this.gl?(this.glVersion=tn.getWebglVersion(),this.textureConf=Fn.getTextureConfig(o),this.MAX_TEXTURE_SIZE=R.get("MAX_TEXTURE_SIZE")||o.getParameter(o.MAX_TEXTURE_SIZE),o.disable(o.DEPTH_TEST),o.disable(o.STENCIL_TEST),o.disable(o.BLEND),o.disable(o.DITHER),o.disable(o.POLYGON_OFFSET_FILL),o.disable(o.SAMPLE_COVERAGE),o.enable(o.SCISSOR_TEST),o.enable(o.CULL_FACE),o.cullFace(o.BACK),this.vertexBuffer=o.createBuffer(),o.bindBuffer(o.ARRAY_BUFFER,this.vertexBuffer),o.bufferData(o.ARRAY_BUFFER,Kn,o.STATIC_DRAW),this.vShader=tn.initShader(o,dn.VS_SHADER,Zn[this.glVersion-1]),this.frameBuffer=o.createFramebuffer(),o.bindFramebuffer(o.FRAMEBUFFER,this.frameBuffer),this.pbo=o.createBuffer(),[2]):[2]})})},n.prototype.createProgram=function(o){var e=this,r=o.op,s=o.outTensor,i=o.inputTensors,a=o.shaderParams,u=o.runtime,f=o.isFinalOp,l=null;try{var c=function(){for(var _=0,h=0,m=arguments.length;h<m;h++)_+=arguments[h].length;var b=Array(_),P=0;for(h=0;h<m;h++)for(var V=arguments[h],T=0,v=V.length;T<v;T++,P++)b[P]=V[T];return b}([s],i);c.forEach(function(_){return tn.genTextureInfoFromTensorShape(e.MAX_TEXTURE_SIZE,_)});var g=ho(this.textureConf,r,c,a,u);(l=new po(this.gl,this.vShader,g,s)).fsCode=g;var d=Fn.genOutputTexture(this.gl,this.textureConf,s,f);this.texturesMap[s.tensorId]=d,this.program=l}catch(_){console.error("webgl createProgram: "+r.name+" -- "+_)}return l},n.prototype.runProgram=function(o,e){var r=this,s=function(a,u){if(u===2&&R.get("performance")){var f=a.getExtension("EXT_disjoint_timer_query_webgl2");if(!f)return;var l=a.createQuery();return a.beginQuery(f.TIME_ELAPSED_EXT,l),l}return null}(this.gl,this.glVersion),i=o.isPackedOp;o.program.forEach(function(a,u){var f=o.outputTensors[u],l=f.tensorId;r.setOutProps(f),o.bufferType==="frameBuffer"?r.attachFrameBuffer(l):r.attachColorBuffer(),a.setProgram(r.gl,r.vertexBuffer,e),r.program=a,r.render(o,e,u,i)}),o.tensorData=null,s&&(this.queryList.push({name:o.name,query:s,count:1}),s=function(a,u,f){if(u===2&&R.get("performance")){var l=a.getExtension("EXT_disjoint_timer_query_webgl2");if(!l)return;a.endQuery(l.TIME_ELAPSED_EXT)}return f}(this.gl,this.glVersion,s))},n.prototype.read=function(o){return yn(this,void 0,void 0,function(){var e,r,s;return En(this,function(i){switch(i.label){case 0:return R.get("webgl_gpu_pipeline")?(e=this.gl,this.frameBuffer=e.createFramebuffer(),e.bindFramebuffer(e.FRAMEBUFFER,this.frameBuffer),[2,[]]):(r=this.createPBO(),[4,this.createAndWaitForFence()]);case 1:return i.sent(),s=o?o.shape:[],[2,this.downloadFloat32TensorFromBuffer(r,s)]}})})},n.prototype.createPBO=function(){var o,e=this.textureConf;if(this.glVersion===2){var r=this.gl,s=this.pbo;r.bindBuffer(r.PIXEL_PACK_BUFFER,s);var i=16*this.width_texture_out*this.height_texture_out;return r.bufferData(r.PIXEL_PACK_BUFFER,i,r.STREAM_READ),r.readPixels(0,0,this.width_texture_out,this.height_texture_out,r.RGBA,r.FLOAT,0),r.bindBuffer(r.PIXEL_PACK_BUFFER,null),s}var a=this.gl,u=a.FLOAT;return e.isFloatTextureReadPixelsEnabled?o=new Float32Array(this.width_texture_out*this.height_texture_out*4):(o=new Uint8Array(this.width_texture_out*this.height_texture_out*4),u=a.UNSIGNED_BYTE),a.readPixels(0,0,this.width_texture_out,this.height_texture_out,a.RGBA,u,o),e.isFloatTextureReadPixelsEnabled?o:new Float32Array(o.buffer)},n.prototype.createAndWaitForFence=function(){return yn(this,void 0,void 0,function(){var o,e,r,s,i=this;return En(this,function(a){return o=this.gl,e=o.fenceSync!=null,r=function(){return!0},e&&(s=o.fenceSync(o.SYNC_GPU_COMMANDS_COMPLETE,0),o.flush(),r=function(){var u=o.clientWaitSync(s,0,0);return u===o.ALREADY_SIGNALED||u===o.CONDITION_SATISFIED}),[2,new Promise(function(u){i.pollItem(r,u)})]})})},n.prototype.pollItem=function(o,e){var r=function(){o()?e():setTimeout(r,1)};r()},n.prototype.downloadFloat32TensorFromBuffer=function(o,e){var r=4*this.width_texture_out*this.height_texture_out;if(this.glVersion===2){var s=this.gl,i=new Float32Array(r);s.bindBuffer(s.PIXEL_PACK_BUFFER,o),s.getBufferSubData(s.PIXEL_PACK_BUFFER,0,i),s.bindBuffer(s.PIXEL_PACK_BUFFER,null);var a=[];if(R.get("webgl_pack_output"))return Array.from(i).slice(0,function(g){return g.reduce(function(d,_){return d*_},1)}(e));for(var u=0;u<this.width_texture_out*this.height_texture_out;u++)a.push(i[4*u]);return a}var f=o,l=[];for(u=0;u<this.width_texture_out*this.height_texture_out;u++){var c=this.textureConf.isFloatTextureReadPixelsEnabled?4*u:u;l.push(f[c])}return l},n.prototype.setOutProps=function(o){var e=o.width_shape,r=e===void 0?1:e,s=o.height_shape,i=s===void 0?1:s,a=o.width_texture,u=a===void 0?1:a,f=o.height_texture,l=f===void 0?1:f,c=o.channel,g=c===void 0?0:c,d=o.total_shape,_=d===void 0?0:d;this.width_shape_out=r,this.height_shape_out=i,this.width_texture_out=u,this.height_texture_out=l,this.channel=g,this.total_shape=_},n.prototype.attachColorBuffer=function(){var o=this.gl;o.bindFramebuffer(o.FRAMEBUFFER,null),o.canvas.width=this.width_shape_out,o.canvas.height=this.height_shape_out,o.viewport(0,0,o.canvas.width,o.canvas.height),o.scissor(0,0,o.canvas.width,o.canvas.height)},n.prototype.attachFrameBuffer=function(o){this.currentTexture=this.texturesMap[o];var e=this.gl;e.framebufferTexture2D(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,this.currentTexture,0),e.viewport(0,0,this.width_texture_out,this.height_texture_out),e.scissor(0,0,this.width_texture_out,this.height_texture_out)},n.prototype.render=function(o,e,r,s){var i=this;e===void 0&&(e=!1),s===void 0&&(s=!1);var a=o.inputTensors,u=a===void 0?[]:a,f=o.uniform,l=f===void 0?null:f,c=o.iLayer,g=c===void 0?0:c,d=o.modelName,_=this.gl,h=0;u.forEach(function(m){i.initTexture(h,m,s);var b=i.getUniformLoc("texture_"+m.name,g,e,r,d);b&&_.uniform1i(b,h++)}),l&&this.setUniform(l,g,e,r,d),_.drawArrays(_.TRIANGLE_STRIP,0,4)},n.prototype.initTexture=function(o,e,r){var s,i=this.gl,a=this.textureConf,u=e.tensorId,f=r||e.isPacked,l=e.data;if(e.persistable){this.cacheTextures=this.cacheTextures||{};var c=this.cacheTextures[u];c?(s=c,l&&tn.genTextureInfoFromTensorShape(this.MAX_TEXTURE_SIZE,e)):(s=i.createTexture(),this.cacheTextures[u]=s)}else s=this.texturesMap[u];i.activeTexture(i["TEXTURE"+o]),i.bindTexture(i.TEXTURE_2D,s),l&&(Fn.uploadDataToTexture(i,a,e,f),e.data=null)},n.prototype.setUniform=function(o,e,r,s,i){var a=this,u=Object.keys(o),f=this.gl;u.forEach(function(l){var c=o[l].type,g=o[l].value,d=a.getUniformLoc(l,e,r,s,i);tn.setUniformParam(f,d,c,g)})},n.prototype.getUniformLoc=function(o,e,r,s,i){var a=i+"_";if(r)return this.uniformLocations[a+e][o+s];var u=this.gl.getUniformLocation(this.program.program,o);return this.uniformLocations[a+e]=this.uniformLocations[a+e]||{},this.uniformLocations[a+e][o+s]=u,u},n.prototype.dispose=function(){},n}(function(){}),wn={mainFunc:function(t,n){var o=t.origin,e=t.filter,r=t.out,s=t.bias,i=n.groups,a=i===void 0?1:i,u=n.strides,f=u===void 0?[]:u,l=n.paddings,c=l===void 0?[]:l,g=n.dilations,d=g===void 0?[]:g,_=n.fuse_relu,h=n.filter_nearest_vec4,m=n.filter_remainder_vec4,b=n.act_type,P=b===void 0?"":b,V=n.padding_algorithm,T=V===void 0?"":V,v=n.hard_swish_offset,E=v===void 0?3:v,A=n.hard_swish_scale,p=A===void 0?6:A,x=n.hard_swish_threshold,y=x===void 0?6:x,F=f[0],w=F===void 0?1:F,O=f[1],S=O===void 0?1:O,I=c[0],L=I===void 0?0:I,C=c[1],N=C===void 0?0:C,X=d[0],G=X===void 0?1:X,k=d[1],j=k===void 0?1:k;return T==="SAME"&&Math.ceil((o.width_shape-e.width_shape)/w)+1!==r.width_shape&&(L=1,N=1),`
    // start函数
    void main(void) {
        ivec4 oPos = getOutputTensorPos();
        int x = oPos.a;
        int c = oPos.g;
        int y = oPos.b;
        int b = oPos.r;
        float res = 0.0;

        // 获取output的坐标
        int oTensorChannel = (c / (`+r.channel+" / "+a+")) * "+e.channel+`;
        int oy = y * `+w+" - "+L+`;
        for (int fy = 0; fy < `+e.height_shape+`; fy++) {
            if (oy >= `+o.height_shape+`) {
                break;
            }
            if (oy < 0) {
                oy += `+G+`;
                continue;
            }
            int ox = x * `+S+" - "+N+`;
            for (int fx = 0; fx < `+e.width_shape+`; fx++) {
                if (ox >= `+o.width_shape+`) {
                    break;
                }
                if (ox < 0) {
                    ox += `+j+`;
                    continue;
                }
                // channel计算
                for (int j = 0; j < `+h+`; j += 4) {
                    vec4 fValues = vec4(
                        getValueFromTensorPos_filter(c, j, fy, fx),
                        getValueFromTensorPos_filter(c, j + 1, fy, fx),
                        getValueFromTensorPos_filter(c, j + 2, fy, fx),
                        getValueFromTensorPos_filter(c, j + 3, fy, fx)
                    );

                    vec4 oValues = vec4(
                        getValueFromTensorPos_origin(b, oTensorChannel + j, oy, ox),
                        getValueFromTensorPos_origin(b, oTensorChannel + j + 1, oy, ox),
                        getValueFromTensorPos_origin(b, oTensorChannel + j + 2, oy, ox),
                        getValueFromTensorPos_origin(b, oTensorChannel + j + 3, oy, ox)
                      );

                    res += dot(fValues, oValues);
                }

                if (`+m+` == 1) {
                    res += dot(
                        getValueFromTensorPos_filter(c, `+h+`, fy, fx),
                        getValueFromTensorPos_origin(b, oTensorChannel + `+h+`, oy, ox));
                } else if (`+m+` == 2) {
                    vec2 fValues = vec2(
                        getValueFromTensorPos_filter(c, `+h+`, fy, fx),
                        getValueFromTensorPos_filter(c, `+h+` + 1, fy, fx)
                    );
                    vec2 oValues = vec2(
                        getValueFromTensorPos_origin(b, oTensorChannel + `+h+`, oy, ox),
                        getValueFromTensorPos_origin(b, oTensorChannel + `+h+` + 1, oy, ox)
                      );
                    res += dot(fValues, oValues);
                } else if (`+m+` == 3) {
                    vec3 fValues = vec3(
                        getValueFromTensorPos_filter(c, `+h+`, fy, fx),
                        getValueFromTensorPos_filter(c, `+h+` + 1, fy, fx),
                        getValueFromTensorPos_filter(c, `+h+` + 2, fy, fx)
                    );
                    vec3 oValues = vec3(
                        getValueFromTensorPos_origin(b, oTensorChannel + `+h+`, oy, ox),
                        getValueFromTensorPos_origin(b, oTensorChannel + `+h+` + 1, oy, ox),
                        getValueFromTensorPos_origin(b, oTensorChannel + `+h+` + 2, oy, ox)
                    );
                    res += dot(fValues, oValues);
                }

                ox += `+j+`;
            }
            oy += `+G+`;
        }

        `+(s?"res += getValueFromTensorPos_bias(0, 0, 0, c);":"")+`

        if (`+_+`) {
            res = max(0.0, res);
        }
        else if (`+(P==="relu6")+`) {
            res = min(max(0.0, res), 6.0);
        }
        else if (`+(P==="hard_swish")+`) {
            res = res * min(
                max(0.0, res + float(`+E+`)),
                float(`+y+`)
            ) / float(`+p+`);
        }

        setOutput(res);
    }
    `},textureFuncConf:{filter:["getValueFromTensorPos"],origin:["getValueFromTensorPos"],bias:["getValueFromTensorPos"]},behaviors:["adaptPaddings","isApplySeparableConv","batchComputeConv2d","processBias"]};function Mn(t,n){var o=t[0],e=t[1],r=t[2],s=t[3];if(o===1&&e===1)return[[1,1,r],3,[s],1,[r,s]];var i=t.slice(0,n),a=t.slice(n);return[i,i.length,a,a.length,[i.reduce(function(u,f){return u*f}),a.reduce(function(u,f){return u*f})]]}function mn(t,n,o){if(o===1)return`
            int getTensorPosFromArrayIndex_`+t+`(int n) {
                return calMod(n, `+n[0]+`);
            }
        `;var e=fn(n);return e.push(1),`
    ivec`+o+" shapeVec_"+t+" = ivec"+o+"("+e.join(", ")+`);
    ivec`+o+" getTensorPosFromArrayIndex_"+t+`(int n) {
        ivec`+o+` pos;
        pos[0] = n / shapeVec_`+t+`[0];
        for (int i = 1; i < `+o+`; i++) {
            n = calMod(n, shapeVec_`+t+`[i - 1]);
            pos[i] = n / shapeVec_`+t+`[i];
        }
        return pos;
    }
    `}function $(t){return t===1?"int":"ivec"+t}function Dn(t){var n=t.total_shape,o=t.channel,e=t.height_shape,r=t.width_shape;return[n/o/e/r,o,e,r]}const Un={mainFunc:function(t,n){var o=t.origin,e=n.transpose_X,r=e!==void 0&&e,s=n.transpose_Y,i=s!==void 0&&s,a=n.trans_x,u=a!==void 0&&a,f=n.trans_y,l=r||u,c=i||f!==void 0&&f;return`
    void main() {
        float res = 0.0;
        // 获取output的坐标
        ivec4 out_pos = getOutputTensorPos();
        ivec4 origin_pos = out_pos;
        if (`+l+`) {
            origin_pos[3] = origin_pos[2];
        }
        ivec4 counter_pos = out_pos;
        if (`+c+`) {
            counter_pos[2] = counter_pos[3];
        }

        for (int j = 0; j < `+(l?o.height_shape:o.width_shape)+`; j++) {
            if (`+l+`) {
                origin_pos[2] = j;
            }
            else {
                origin_pos[3] = j;
            }
            if (`+c+`) {
                counter_pos[3] = j;
            }
            else {
                counter_pos[2] = j;
            }
            float o = getValueFromTensorPos_origin(origin_pos[0], origin_pos[1], origin_pos[2], origin_pos[3]);
            float c = getValueFromTensorPos_counter(counter_pos[0], counter_pos[1], counter_pos[2], counter_pos[3]);
            
            res += c * o;
        }
        setOutput(res);
    }
    `},textureFuncConf:{counter:["getValueFromTensorPos"],origin:["getValueFromTensorPos"]}};function Nn(t,n){var o=t[0],e=t[1],r=t[2],s=t[3];if(o===1&&e===1)return[[1,1,r],3,[s],1,[r,s]];var i=t.slice(0,n),a=t.slice(n);return[i,i.length,a,a.length,[i.reduce(function(u,f){return u*f}),a.reduce(function(u,f){return u*f})]]}function Pn(t,n,o){if(o===1)return`
            int getTensorPosFromArrayIndex_`+t+`(int n) {
                return calMod(n, `+n[0]+`);
            }
        `;var e=fn(n);return e.push(1),`
    ivec`+o+" shapeVec_"+t+" = ivec"+o+"("+e.join(", ")+`);
    ivec`+o+" getTensorPosFromArrayIndex_"+t+`(int n) {
        ivec`+o+` pos;
        pos[0] = n / shapeVec_`+t+`[0];
        for (int i = 1; i < `+o+`; i++) {
            n = calMod(n, shapeVec_`+t+`[i - 1]);
            pos[i] = n / shapeVec_`+t+`[i];
        }
        return pos;
    }
    `}function J(t){return t===1?"int":"ivec"+t}function jn(t){var n=t.total_shape,o=t.channel,e=t.height_shape,r=t.width_shape;return[n/o/e/r,o,e,r]}const Vn={mainFunc:function(t,n){return`
    // start函数
    void main(void) {
        vec2 outCoord = vCoord.xy * (_2d_shape_texture_out);
        int index = int(outCoord.x) + int(outCoord.y) * int(`+t.out.width_texture+`);
        ivec4 originPos = getTensorPosFromArrayIndex_origin(index);
        float res = getValueFromTensorPos_origin(originPos[0], originPos[1], originPos[2], originPos[3]);
        setOutput(res);
    }
    `},textureFuncConf:{origin:["getTensorPosFromArrayIndex","getValueFromTensorPos"]}},Xn={mainFunc:function(t,n){var o=t.out,e=t.origin,r=n.align_mode,s=r===void 0?1:r,i=n.align_corners,a=i===void 0||i;return`
    // start函数

    vec4 getData(float n, float scale, bool align_flag, int in_len) {
        float m = align_flag ? ((n + 0.5) / scale - 0.5) : (n / scale);
        int a1 = int(floor(m));
        a1 = a1 > 0 ? a1 : 0;
        int a2 = (a1 + 1) < (in_len - 1) ? (a1 + 1) : (in_len - 1);

        float idx_src = (n + 0.5) / scale - 0.5;
        idx_src = idx_src > 0.0 ? idx_src : 0.0;
        float b1 = align_flag ? (idx_src - float(a1)) : (n / scale - float(a1));
        float b2 = 1.0 - b1;
        return vec4(float(a1), float(a2), b1, b2);
    }

    void main(void) {
        // 输出数据
        ivec4 oPos = getOutputTensorPos();

        bool align_flag = `+s+" == 0 && !"+a+`;

        float scale_x = 0.0;
        float scale_y = 0.0;
        if (`+a+`) {
            scale_x = float(`+o.width_shape+" - 1) / float("+e.width_shape+` - 1);
            scale_y = float(`+o.height_shape+" - 1) / float("+e.height_shape+` - 1);
        }
        else {
            scale_x = float(`+o.width_shape+") / float("+e.width_shape+`);
            scale_y = float(`+o.height_shape+") / float("+e.height_shape+`);
        }

        vec4 vx = getData(float(oPos.a), scale_x, align_flag, `+e.width_shape+`);
        vec4 vy = getData(float(oPos.b), scale_y, align_flag, `+e.height_shape+`);

        int x1 = int(vx.r);
        int x2 = int(vx.g);
        float x3 = vx.b;
        float x4 = vx.a;
        int y1 = int(vy.r);
        int y2 = int(vy.g);
        float y3 = vy.b;
        float y4 = vy.a;

        float value11 = getValueFromTensorPos_origin(oPos.r, oPos.g, y1, x1);
        float value12 = getValueFromTensorPos_origin(oPos.r, oPos.g, y2, x1);
        float value21 = getValueFromTensorPos_origin(oPos.r, oPos.g, y1, x2);
        float value22 = getValueFromTensorPos_origin(oPos.r, oPos.g, y2, x2);
        float value = x4 * y4 * value11 + x4 * y3 * value12 + x3 * y4 * value21 + x3 * y3 * value22;
        setOutput(float(value));
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"]}},vo=Xn;var xo={relu:["transToPrelu"],relu6:["transToRelu6"],leaky_relu:["transToLeakyrelu"],transToLeakyrelu:["transToLeakyrelu"],scale:["transToScale"],sigmoid:["transToSigmoid"],hard_sigmoid:["transToHardSigmoid"],pow:["transToPow"],exp:["transToExp"],sqrt:["transToSqrt"],tanh:["transToTanh"]};function To(t,n){var o=n.multi_value,e=o===void 0?1:o,r=n.bias_value,s=r===void 0?0:r;return`
    // start函数
    void main(void) {
        // 输出数据
        float o = getPixelsFromTexturePos_origin(vCoord).r;
        float res = `+n.active_function+"(o, float("+e+"), float("+s+`));
        setOutput(res);
    }
    `}function Y(t){return{mainFunc:To,textureFuncConf:{origin:["getPixelsFromTexturePos"]},behaviors:xo[t]}}const Fo={mainFunc:function(t,n){var o=n.axes,e=Array.isArray(o)?o:[o],r=[0,1,2,3].filter(function(s){return s>=e.length});return`
    // start函数
    void main(void) {
        ivec4 oPos = getOutputTensorPos();
        // 输出坐标转换为输入坐标
        float o = 0.0;
        o = getValueFromTensorPos_origin(`+[0,1,2,3].map(function(s){return e.indexOf(s)>-1?0:"oPos["+r.splice(0,1)+"]"}).join(",")+`);
        setOutput(float(o));
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"]}},Gn={mainFunc:function(t,n){var o=t.origin,e=t.out,r=n.align_corners;return`
    // start函数
    int getData(float n, float scale, bool align_corners) {
        float m = align_corners ? (n / scale + 0.5) : (n / scale);
        return int(floor(m));
    }

    void main(void) {
        // 输出数据
        ivec4 oPos = getOutputTensorPos();
        
        float scale_x = 0.0;
        float scale_y = 0.0;
        if (`+r+`) {
            scale_x = float(`+e.width_shape+" -1) / float("+o.width_shape+` - 1);
            scale_y = float(`+e.height_shape+" - 1) / float("+o.height_shape+` - 1);
        }
        else {
            scale_x = float(`+e.width_shape+") / float("+o.width_shape+`);
            scale_y = float(`+e.height_shape+") / float("+o.height_shape+`);
        }
    
        int vx = getData(float(oPos.a), scale_x, `+r+`);
        int vy = getData(float(oPos.b), scale_y, `+r+`);
        
        float o = getValueFromTensorPos_origin(oPos.r, oPos.g, vy, vx);
        setOutput(float(o));
}
    `},textureFuncConf:{origin:["getValueFromTensorPos"]},commonFuncConf:["transferFromNHWCtoNCHW"]};var bo=function(){for(var t=0,n=0,o=arguments.length;n<o;n++)t+=arguments[n].length;var e=Array(t),r=0;for(n=0;n<o;n++)for(var s=arguments[n],i=0,a=s.length;i<a;i++,r++)e[r]=s[i];return e};const yo={mainFunc:function(t,n){var o=t.origin,e=t.image,r=t.out,s=n.variances,i=s===void 0?[.1,.1,.2,.2]:s,a=n.fixed_sizes,u=n.fixed_ratios,f=n.densities,l=n.flatten_to_2d,c=n.clip,g=n.step_w,d=g===void 0?0:g,_=n.step_h,h=_===void 0?0:_,m=n.offset,b=m===void 0?.5:m,P=n.runtime,V=P===void 0?0:P,T=e.height_shape,v=e.width_shape,E=o.height_shape,A=o.width_shape,p=r.total_shape,x=r.channel,y=r.height_shape,F=r.width_shape,w=p/x/y/F,O=fn([w,x,y,F]),S=d,I=h;d!==0&&h!==0||(S=v/A,I=T/E);var L=Math.round(.5*(S+I)),C=u.map(function(q){return Math.sqrt(q)}),N=C.length===1?"sqrt_fixed_ratios":"sqrt_fixed_ratios[r]",X=u.length,G=y,k=w,j=x;l&&(k=E,j=A,G=y/E/A);var an=fn([k,j,G,F]),nn=kn("out1",{numbers_shape:bo(an,[1]),length_shape:4}),K=f.map(function(q){return q*q*X}),W=K.length,Ao=function(q){var un="ivec2 calRemain(int remain, int curAccIndex, int s) {",ln=q.length;if(ln===1)un+=`
            int accIndex0 = density_acc_shape;

            if (remain >= accIndex0) {
                s++;
                remain -= accIndex0;
            }
            else {
                return ivec2(remain, s);
            }
            `;else for(var Q=0;Q<ln;Q++)un+=`
            int accIndex`+Q+" = density_acc_shape["+Q+`];

            if (remain >= accIndex`+Q+`) {
                s++;
                remain -= accIndex`+Q+`;
            }
            else {
                return ivec2(remain, s);
            }
            `;return un+`
    }
    `}(K),Oo=c?"v = min(max(v, 0.), 1.);":"",Co=W===1?"density_acc_shape":"density_acc_shape[0]",zn=`
    float getFloat4TensorVal(vec4 tensor, int index) {
        if (index == 0) {
            return tensor[0];
        }
        else if (index == 1) {
            return tensor[1];
        }
        else if (index == 2) {
            return tensor[2];
        }
        else if (index == 3) {
            return tensor[3];
        }
    }
    float getFloat3TensorVal(vec3 tensor, int index) {
        if (index == 0) {
            return tensor[0];
        }
        else if (index == 1) {
            return tensor[1];
        }
        else if (index == 2) {
            return tensor[2];
        }
    }
    float getFloat2TensorVal(vec2 tensor, int index) {
        if (index == 0) {
            return tensor[0];
        }
        else if (index == 1) {
            return tensor[1];
        }
    }
    float getFloat1TensorVal(float tensor, int index) {
        return tensor;
    }
    int getInt4TensorVal(ivec4 tensor, int index) {
        if (index == 0) {
            return tensor[0];
        }
        else if (index == 1) {
            return tensor[1];
        }
        else if (index == 2) {
            return tensor[2];
        }
        else if (index == 3) {
            return tensor[3];
        }
    }
    int getInt3TensorVal(ivec3 tensor, int index) {
        if (index == 0) {
            return tensor[0];
        }
        else if (index == 1) {
            return tensor[1];
        }
        else if (index == 2) {
            return tensor[2];
        }
    }
    int getInt2TensorVal(ivec2 tensor, int index) {
        if (index == 0) {
            return tensor[0];
        }
        else if (index == 1) {
            return tensor[1];
        }
    }

    int getInt1TensorVal(int tensor, int index) {
       return tensor;
    }

    `+nn+`
    
        `+cn(f,"densities")+`
        `+cn(a,"fixed_sizes")+`
        `+cn(C,"sqrt_fixed_ratios")+`
        `+function(q,un){if(q.length===1)return"int "+un+" = int("+q[0]+");";for(var ln=q.length,Q=`
        ivec`+ln+" "+un+" = ivec"+ln+`(
    `,An=0;An<ln;An++)Q+=q[An]+",";return Q.slice(0,-1)+");"}(K,"density_acc_shape")+`
    
    `+Ao+`
    // start函数
    void main(void) {
        ivec4 oPos = getOutputTensorPos();
        int rr = int(oPos.r);
        int gg = int(oPos.g);
        int bb = int(oPos.b);
        int aa = int(oPos.a);

        // 输出坐标转换为输入坐标
        int index = rr * `+O[0]+" + gg * "+O[1]+" + bb * "+O[2]+` + aa;
        ivec4 realOutPos = getTensorPosFromArrayIndex_out1(index);
        int h = realOutPos.r;
        int w = realOutPos.g;
        int b = realOutPos.b;
        int a = realOutPos.a;
    `;return V===1?`
        `+cn(i,"variances")+`
        `+zn+`
        setOutput(getFloat4TensorVal(variances, aa));
        }`:`
            `+zn+`
            // 求idx 对应的 s, r, di, dj
            int s = 0;
            int remain = b;
            int curAccIndex = `+Co+`;

            ivec2 remainInfo = calRemain(remain, curAccIndex, s);
            remain = remainInfo[0];
            s = remainInfo[1];
            int density = int(getFloat`+f.length+`TensorVal(densities, s));
            int r = int(floor(float(remain / density / density)));
            remain -= r * density * density;

            float di = floor(float(remain / density));
            float dj = float(remain - int(di) * density);

            float center_x = (float(w) + float(`+b+")) * float("+S+`);
            float center_y = (float(h) + float(`+b+")) * float("+I+`);
            float fixed_size = getFloat`+a.length+`TensorVal(fixed_sizes, s);
            float shift = float(`+L+`) / float(density);

            float v = 0.0;
            if (a == 0 || a == 2) {
                float box_width_ratio = fixed_size * `+N+`;
                float density_center_x = center_x - float(`+L+`) / 2. + shift / 2.;
                float center_x_temp = density_center_x + dj * shift;
                if (a == 0) {
                    v = max((center_x_temp - box_width_ratio / 2.) / float(`+v+`), 0.);
                }
                else {
                    v = min((center_x_temp + box_width_ratio / 2.) / float(`+v+`), 1.);
                }
            }
            else {
                float box_height_ratio = fixed_size / `+N+`;
                float density_center_y = center_y - float(`+L+`) / 2. + shift / 2.;
                float center_y_temp = density_center_y + di * shift;
                if (a == 1) {
                    v = max((center_y_temp - box_height_ratio / 2.) / float(`+T+`), 0.);
                }
                else {
                    v = min((center_y_temp + box_height_ratio / 2.) / float(`+T+`), 1.);
                }
            }

            `+Oo+`

            setOutput(v);
        }
        `},textureFuncConf:{image:["getValueFromTensorPos"],origin:["getValueFromTensorPos"]}},Eo={mainFunc:function(t,n){var o=t.origin,e=t.image,r=t.out,s=n.variances,i=s===void 0?[.1,.1,.2,.2]:s,a=n.flip,u=n.clip,f=n.step_w,l=f===void 0?0:f,c=n.step_h,g=c===void 0?0:c,d=n.offset,_=d===void 0?.5:d,h=n.runtime,m=h===void 0?0:h,b=n.min_sizes,P=b===void 0?[]:b,V=n.max_sizes,T=V===void 0?[]:V,v=n.aspect_ratios,E=v===void 0?[]:v,A=n.min_max_aspect_ratios_order,p=A!==void 0&&A,x=e.height_shape,y=e.width_shape,F=o.height_shape,w=o.width_shape,O=r.channel,S=r.height_shape,I=l,L=g;l!==0&&g!==0||(I=y/w,L=x/F);var C=[1];E.forEach(function(j){j!==1&&(C.push(Math.sqrt(j)),a&&C.push(Math.sqrt(1/j)))});var N=C.length,X=`
        `+gn(P,"min_sizes",Z.FLOAT_TYPE)+`
        `+gn(T,"max_sizes",Z.FLOAT_TYPE)+`
        `+gn(C,"aspect_ratios",Z.FLOAT_TYPE)+`
    `,G=u?"res = min(max(res, 0.), 1.);":"",k=`
    float getFloat4TensorVal(vec4 tensor, int index) {
        if (index == 0) {
            return tensor[0];
        }
        else if (index == 1) {
            return tensor[1];
        }
        else if (index == 2) {
            return tensor[2];
        }
        else if (index == 3) {
            return tensor[3];
        }
    }

    
        `+hn(P,"min_sizes",Z.FLOAT_TYPE)+`
        `+hn(T,"max_sizes",Z.FLOAT_TYPE)+`
        `+hn(C,"aspect_ratios",Z.FLOAT_TYPE)+`
    

    // start函数
    void main(void) {
        ivec4 oPos = getOutputTensorPos();
        int nn = int(oPos.r);
        int cc = int(oPos.g);
        int hh = int(oPos.b);
        int ww = int(oPos.a);


        `+X+`

    `;return m===1?`
            `+cn(i,"variances")+`
            `+k+`
            float res = 0.0;
            res = getFloat4TensorVal(variances, ww);
            setOutput(float(res));
        }`:`
            `+k+`
            int idx = nn * `+O*S+" + cc * "+S+` + hh;
            int as_num = `+N+`;
            float offset = `+_+`;
            
            int feature_width = `+w+`;
            int num_priors = `+S+`;
            float step_width = float(`+I+`);
            float step_height = float(`+L+`);

            float im_width = float(`+y+`);
            float im_height = float(`+x+`);

            bool min_max_aspect_ratios_order = `+p+`;

            // 求idx 对应的 h w p m
            int h = int(idx / (num_priors * feature_width));
            int w = calMod(idx / num_priors, feature_width);
            int p = calMod(idx, num_priors);
            int m = `+(T.length>0)+` ? int(p / (as_num + 1)) : int(p / as_num);
            float cx = (float(w) + offset) * step_width;
            float cy = (float(h) + offset) * step_height;
            float min_size = getValueFromArrByIndex_min_sizes(min_sizes, m);
            float bw = 0.0;
            float bh = 0.0;

            `+(T.length>0?`
            int s = calMod(p, as_num + 1);
            if (`+!p+`) {
                if (s < as_num) {
                    float ar = getValueFromArrByIndex_aspect_ratios(aspect_ratios, s);
                    bw = min_size * ar / 2.0;
                    bh = min_size / ar / 2.0;
                }
                else {
                    float max_size = getValueFromArrByIndex_max_sizes(max_sizes, m);
                    bw = sqrt(min_size * max_size) / 2.0;
                    bh = bw;
                }
            }
            else {
                if (s == 0) {
                    bh = min_size / 2.0;
                    bw = bh;
                }
                else if (s == 1) {
                    float max_size = getValueFromArrByIndex_max_sizes(max_sizes, m);
                    bw = sqrt(min_size * max_size) / 2.0;
                    bh = bw;
                }
                else {
                    float ar = getValueFromArrByIndex_aspect_ratios(aspect_ratios, s - 1);
                    bw = min_size * sqrt(ar) / 2.0;
                    bh = min_size / sqrt(ar) / 2.0;
                }
            }`:`
            int s = calMod(p, as_num);
            float ar = getValueFromArrByIndex_aspect_ratios(aspect_ratios, s);
            bw = min_size * ar / 2.0;
            bh = min_size / ar / 2.0;
        `)+`
            float res = 0.0;
            if (ww == 0) {
                res = (cx - bw) / im_width;
            }
            else if (ww == 1) {
                res = (cy - bh) / im_height;
            }
            else if (ww == 2) {
                res = (cx + bw) / im_width;
            }
            else {
                res = (cy + bh) / im_height;
            }

            `+G+`

            setOutput(float(res));
        }
        `},textureFuncConf:{image:["getValueFromTensorPos"],origin:["getValueFromTensorPos"]},behaviors:[]},wo={mainFunc:function(t,n){for(var o=t.out,e=function(P,V){var T={};for(var v in P)Object.prototype.hasOwnProperty.call(P,v)&&V.indexOf(v)<0&&(T[v]=P[v]);if(P!=null&&typeof Object.getOwnPropertySymbols=="function"){var E=0;for(v=Object.getOwnPropertySymbols(P);E<v.length;E++)V.indexOf(v[E])<0&&Object.prototype.propertyIsEnumerable.call(P,v[E])&&(T[v[E]]=P[v[E]])}return T}(t,["out"]),r=e.origin,s=r.width_shape,i=r.height_shape,a=r.channel,u=r.total_shape,f=r.length_unformatted_shape,l=[u/(s*i*a),a,i,s].slice(4-f),c=Object.keys(e).length,g=n.axis<0?n.axis+l.length+1:n.axis,d=1,_=1,h=0;h<g;h++)d*=l[h];for(h=g;h<l.length;h++)_*=l[h];var m=o.total_shape/d,b="";return b=Array.from(Array(c).keys()).reduce(function(P,V){return P+(V===0?`
            if (i == 0) {
                ivec4 co = getTensorPosFromArrayIndex_origin(j);
                o = getValueFromTensorPos_origin(co.r, co.g, co.b, co.a);
            }`:`
            else if (i == `+V+`) {
                ivec4 co = getTensorPosFromArrayIndex_origin_`+V+`(j);
                o = getValueFromTensorPos_origin_`+V+`(co.r, co.g, co.b, co.a);
            }`)},b),`
    // start函数
    void main(void) {
        ivec4 oPos = getOutputTensorPos();
        // 输出坐标转换为输入坐标
        int sumVal = oPos.a
            + oPos.b * `+o.width_shape+`
            + oPos.g * `+o.height_shape+" * "+o.width_shape+`
            + oPos.r * `+o.channel+" * "+o.width_shape+" * "+o.height_shape+`;

        int index = calMod(sumVal, `+m+`);

        int layer = sumVal / `+m+`;

        int i = index / `+_+`;
        int j = calMod(index, `+_+") + layer * "+_+`;

        float o = 0.0;
        `+b+`
        setOutput(float(o));
    }
    `},textureFuncConf:{"@all":["getValueFromTensorPos","getTensorPosFromArrayIndex"]}},Vo={mainFunc:function(t,n){var o=t.out,e=t.origin,r=n.axes,s=n.starts,i=n.ends,a=n.decrease_axis;if(r.length>1||s.length>1||i.length>1||a&&a.length===0)throw Error("[slice op feature]: current support one dim, support decrease_axis");var u=e.width_shape,f=e.height_shape,l=e.channel,c=e.total_shape,g=e.length_unformatted_shape,d=[c/(u*f*l),l,f,u],_=r[0];if(_<0&&(_=_+g+1),(_=4-g+_)!==4)throw Error("[slice op feature]: unsupport axis value");for(var h=s[0],m=i[0],b=d[0],P=d[1],V=d[2],T=d[3],v=[],E=h;E<m;E++)for(var A=0;A<b;A++)for(var p=0;p<P;p++)for(var x=0;x<V;x++)v.push(A*P*V*T+p*V*T+x*T+E);var y=gn(v,"arr",Z.INT_TYPE);return`
    `+hn(v,"arr",Z.INT_TYPE)+`

    void main(void) {
        ivec4 oPos = getOutputTensorPos();
        `+y+`

        // 输出坐标转换为输入坐标
        int sumVal = oPos.a
            + oPos.b * `+o.width_shape+`
            + oPos.g * `+o.height_shape+" * "+o.width_shape+`
            + oPos.r * `+o.channel+" * "+o.width_shape+" * "+o.height_shape+`;

        int index = getValueFromArrByIndex_arr(arr, sumVal);

        float res = 0.0;
        ivec4 co = getTensorPosFromArrayIndex_origin(index);
        res = getValueFromTensorPos_origin(co.r, co.g, co.b, co.a);
        setOutput(float(res));
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos","getTensorPosFromArrayIndex"]}};var Hn={arg_max:{mainFunc:function(t,n){var o=t.origin,e=n.axis,r=e===void 0?-1:e,s=n.flatten,i=o.total_shape,a=o.height_shape,u=o.width_shape,f=o.channel,l=o.length_unformatted_shape,c=i/(u*a*f),g=r<0?3:4-l+r,d=[c,f,a,u][g];return`

    void main() {
        ivec4 oPos = getOutputTensorPos();
        float o = 0.0;
        int pos = 0;
        if (`+!s+`) {
            if (`+g+` == 1) {
                float tmp = getValueFromTensorPos_origin(oPos.g, 0, oPos.b, oPos.a);
                for (int index = 0; index < `+d+`; index++) {
                    o = getValueFromTensorPos_origin(oPos.g, index, oPos.b, oPos.a);
                    if (o > tmp) {
                        tmp = o;
                        pos = index;
                    }
                }
            }
            else if (`+g+` == 2) {
                float tmp = getValueFromTensorPos_origin(oPos.g, oPos.b, 0, oPos.a);
                for (int index = 0; index < `+d+`; index++) {
                    o = getValueFromTensorPos_origin(oPos.g, oPos.b, index, oPos.a);
                    if (o > tmp) {
                        tmp = o;
                        pos = index;
                    }
                }
            }
            else if (`+g+` == 3) {
                float tmp = getValueFromTensorPos_origin(oPos.g, oPos.b, oPos.a, 0);
                for (int index = 0; index < `+d+`; index++) {
                    o = getValueFromTensorPos_origin(oPos.g, oPos.b, oPos.a, index);
                    if (o > tmp) {
                        tmp = o;
                        pos = index;
                    }
                }
            }
            else {
                float tmp = getValueFromTensorPos_origin(0, oPos.g, oPos.b, oPos.a);
                for (int index = 0; index < `+d+`; index++) {
                    o = getValueFromTensorPos_origin(index, oPos.g, oPos.b, oPos.a);
                    if (o > tmp) {
                        tmp = o;
                        pos = index;
                    }
                }
            }
        }
        else {
            int index = 0;
            float tmp = getValueFromTensorPos_origin(0, 0, 0, 0);
            for (int n = 0; n < `+c+`; n++) {
                for (int c = 0; c < `+f+`; c++) {
                    for (int h = 0; h < `+a+`; h++) {
                        for (int w = 0; w < `+u+`; w++) {
                            o = getValueFromTensorPos_origin(n, c, h, w);
                            if (o > tmp) {
                                tmp = o;
                                pos = index;
                            }
                            index++;
                        }
                    }
                }
            }
        }
        setOutput(float(pos));
    }`},textureFuncConf:{origin:["getValueFromTensorPos"]}},arg_min:{mainFunc:function(t,n){for(var o=t.origin,e=n.axis,r=e===void 0?-1:e,s=n.flatten,i=o.total_shape,a=o.height_shape,u=o.width_shape,f=o.channel,l=i/(u*a*f),c=[l,f,a,u],g=0,d=0;d<4&&!(c[d]>1);d++)g++;var _=r<0?4-g+r:r,h=c[_=g+_];return`
    void main() {
        ivec4 oPos = getOutputTensorPos();
        float o = 0.0;
        int pos = 0;
        if (`+!s+`) {
            if (`+_+` == 1) {
                float tmp = getValueFromTensorPos_origin(oPos.g, 0, oPos.b, oPos.a);
                for (int index = 0; index < `+h+`; index++) {
                    o = getValueFromTensorPos_origin(oPos.g, index, oPos.b, oPos.a);
                    if (o < tmp) {
                        tmp = o;
                        pos = index;
                    }
                }
            }
            else if (`+_+` == 2) {
                float tmp = getValueFromTensorPos_origin(oPos.g, oPos.b, 0, oPos.a);
                for (int index = 0; index < `+h+`; index++) {
                    o = getValueFromTensorPos_origin(oPos.g, oPos.b, index, oPos.a);
                    if (o < tmp) {
                        tmp = o;
                        pos = index;
                    }
                }
            }
            else if (`+_+` == 3) {
                float tmp = getValueFromTensorPos_origin(oPos.g, oPos.b, oPos.a, 0);
                for (int index = 0; index < `+h+`; index++) {
                    o = getValueFromTensorPos_origin(oPos.g, oPos.b, oPos.a, index);
                    if (o < tmp) {
                        tmp = o;
                        pos = index;
                    }
                }     
            }
            else {
                float tmp = getValueFromTensorPos_origin(0, oPos.g, oPos.b, oPos.a);
                for (int index = 0; index < `+h+`; index++) {
                    o = getValueFromTensorPos_origin(index, oPos.g, oPos.b, oPos.a);
                    if (o < tmp) {
                        tmp = o;
                        pos = index;
                    }
                }
            }
        }
        else {
            int index = 0;
            float tmp = getValueFromTensorPos_origin(0, 0, 0, 0);
            for (int n = 0; n < `+l+`; n++) {
                for (int c = 0; c < `+f+`; c++) {
                    for (int h = 0; h < `+a+`; h++) {
                        for (int w = 0; w < `+u+`; w++) {
                            o = getValueFromTensorPos_origin(n, c, h, w);
                            if (o < tmp) {
                                tmp = o;
                                pos = index;
                            }
                            index++;
                        }
                    }
                }
            }
        }
        setOutput(float(pos));
    }`},textureFuncConf:{origin:["getValueFromTensorPos"]}},conv2d:wn,conv2d_packing:{mainFunc:function(t,n){var o=t.origin,e=t.filter,r=t.out,s=t.bias,i=n.groups,a=i===void 0?1:i,u=n.strides,f=u===void 0?[]:u,l=n.paddings,c=l===void 0?[]:l,g=n.dilations,d=g===void 0?[]:g,_=n.fuse_relu,h=n.act_type,m=n.hard_swish_offset,b=m===void 0?3:m,P=n.hard_swish_scale,V=P===void 0?6:P,T=n.hard_swish_threshold,v=T===void 0?6:T,E=f[0],A=E===void 0?1:E,p=f[1],x=p===void 0?1:p,y=c[0],F=y===void 0?0:y,w=c[1],O=w===void 0?0:w,S=d[0],I=S===void 0?1:S,L=d[1],C=L===void 0?1:L;return`
    void main() {
        ivec4 oPos = getOutputTensorPos();
        int x = oPos.a;
        int c = oPos.g;
        int y = oPos.b;
        int b = oPos.r;
        vec4 res = vec4(0.0, 0.0, 0.0, 0.0);

        int oy = y * `+A+" - "+F+`;
        for (int fy = 0; fy < `+e.height_shape+`; fy++) {
            if (oy >= `+o.height_shape+`) {
                break;
            }
            if (oy < 0) {
                oy += `+I+`;
                continue;
            }
            int ox = x * `+x+" - "+O+`;
            for (int fx = 0; fx < `+e.width_shape+`; fx++) {
                if (ox >= `+o.width_shape+`) {
                    break;
                }
                if (ox < 0) {
                    ox += `+C+`;
                    continue;
                }
                // channel计算
                for (int j = 0; j < `+e.channel+`; j += 1) {
                    int c0 = (c / (`+r.channel+" * 4 / "+a+")) * "+e.channel+` + j;
                    vec4 fValue = getValueFromTensorPosPacking_filter(c * 4, j, fy, fx);
                    vec4 oValue = getValueFromTensorPosPacking_origin(b, c0, oy, ox);

                    for (int packed_index = 0; packed_index < 4; packed_index++) {
                        if (packed_index == 0) {
                            res.r += dot(fValue, oValue);
                        } else if (packed_index == 1) {
                            int c1 = ((c + 1) / (`+r.channel+" * 4 / "+a+")) * "+e.channel+` + j;
                            oValue = getValueFromTensorPosPacking_origin(b, c1, oy, ox);
                            fValue = getValueFromTensorPosPacking_filter(c * 4 + 1, j, fy, fx);
                            res.g += dot(fValue, oValue);
                        } else if (packed_index == 2) {
                            int c2 = ((c + 2) / (`+r.channel+" * 4 / "+a+")) * "+e.channel+` + j;
                            oValue = getValueFromTensorPosPacking_origin(b, c2, oy, ox);
                            fValue = getValueFromTensorPosPacking_filter(c * 4 + 2, j, fy, fx);
                            res.b += dot(fValue, oValue);
                        } else if (packed_index == 3) {
                            int c3 = ((c + 3) / (`+r.channel+" * 4 / "+a+")) * "+e.channel+` + j;
                            oValue = getValueFromTensorPosPacking_origin(b, c3, oy, ox);
                            fValue = getValueFromTensorPosPacking_filter(c * 4 + 3, j, fy, fx);
                            res.a += dot(fValue, oValue);
                        }
                    }
                }
                ox += `+C+`;
            }
            oy += `+I+`;
        }

        `+(s?"res += getValueFromTensorPosPacking_bias(0, c, 0, 0);":"")+`

        if (`+_+`) {
            res = max(vec4(0.0, 0.0, 0.0, 0.0), res);
        }
        else if (`+(h==="relu6")+`) {
            res = min(max(vec4(0.0, 0.0, 0.0, 0.0), res), vec4(6.0, 6.0, 6.0, 6.0));
        }
        else if (`+(h==="hard_swish")+`) {
            res = res * min(
                max(vec4(0.0, 0.0, 0.0, 0.0), res + vec4(`+b+`)),
                vec4(`+v+`)
            ) / vec4(`+V+`);
        }

        setPackedOutput(res);
    }
    `},textureFuncConf:{filter:["getValueFromTensorPosPacking"],origin:["getValueFromTensorPosPacking"],bias:["getValueFromTensorPosPacking"]},behaviors:["adaptPaddings","isApplySeparableConv","batchComputeConv2d","processBias"]},conv2d_transpose:{mainFunc:function(t,n){var o=t.origin,e=t.filter,r=t.out,s=t.bias,i=n.groups,a=i===void 0?1:i,u=n.strides,f=u===void 0?[]:u,l=n.paddings,c=l===void 0?[]:l,g=n.dilations,d=g===void 0?[]:g,_=n.fuse_relu,h=n.act_type,m=f[0],b=m===void 0?1:m,P=f[1],V=P===void 0?1:P,T=c[0],v=T===void 0?0:T,E=c[1],A=E===void 0?0:E;A=e.height_shape-A-1,v=e.width_shape-v-1;var p=d[0],x=p===void 0?1:p,y=d[1],F=y===void 0?1:y;return`
    // start函数
    void main(void) {
        ivec4 oPos = getOutputTensorPos();
        int x = oPos.a;
        int c = oPos.g;
        int y = oPos.b;
        int b = oPos.r;
        float res = 0.0;
        int temp_x = 0;
        int temp_y = 0;
        float o = 0.0;
        float f = 0.0;

        // 获取output的坐标
        int oTensorChannel = int(c * `+a+" / "+r.channel+") * "+o.channel+`;
        int oy = y - `+A+`;
        const int groupLen = int(`+o.channel+" / "+a+`);
        int groupIndex = int(c / groupLen);

        for (int fy = 0; fy < `+e.height_shape+`; fy++) {
            if (oy < 0) {
                oy += `+x+`;
                continue;
            }
            int ox = x - `+v+`;
            for (int fx = 0; fx < `+e.width_shape+`; fx++) {

                if (ox < 0) {
                    ox += `+F+`;
                    continue;
                }
                // channel计算
                for (int j = 0; j < groupLen; j++) {
                    int curIndex = j + b * groupLen;
                    if (calMod(ox, int(`+V+")) == 0 && calMod(oy, int("+b+`)) == 0) {
                        temp_x = int(floor(float(ox) / float(`+V+`)));
                        temp_y = int(floor(float(oy) / float(`+b+`)));
                        if (temp_x < `+o.width_shape+" && temp_y < "+o.height_shape+`) {
                            o = getValueFromTensorPos_origin(b, curIndex , temp_y, temp_x);
                            f = getValueFromTensorPos_filter(
                                curIndex,
                                int(c / `+a+`),
                                `+e.height_shape+`-1-fy,
                                `+e.width_shape+`-1-fx
                            );
                            res += f * o;
                        }
                    }
                }
                ox += `+F+`;
            }
            oy += `+x+`;
        }
        
        `+(s?"res += getValueFromTensorPos_bias(0, 0, 0, c);":"")+`
        
        if (`+_+`) {
            res = max(0.0, res);
        }
        else if (`+(h==="relu6")+`) {
            res = min(max(0.0, res), 6.0);
        }
        
        setOutput(float(res));
    }
`},textureFuncConf:{filter:["getValueFromTensorPos"],origin:["getValueFromTensorPos"],bias:["getValueFromTensorPos"]},behaviors:["adaptPaddings","isApplySeparableConv","batchComputeConv2d","processBias"]},depthwise_conv2d:wn,conv2d_depthwise:wn,conv2d_elementwise_add:{mainFunc:function(t,n){var o=t.origin,e=t.filter,r=t.out,s=t.counter,i=n.active_function,a=n.groups,u=a===void 0?1:a,f=n.axis,l=n.strides,c=l===void 0?[]:l,g=n.paddings,d=g===void 0?[]:g,_=n.dilations,h=_===void 0?[]:_,m=n.multi_value,b=n.bias_value,P=c[0],V=P===void 0?1:P,T=c[1],v=T===void 0?1:T,E=d[0],A=E===void 0?0:E,p=d[1],x=p===void 0?0:p,y=h[0],F=y===void 0?1:y,w=h[1],O=w===void 0?1:w;return`
    // start函数

    float getValueFromCounter(int index) {
        float xPos = float(index) / float(`+s.width_shape+`);
        vec4 pixels = TEXTURE2D(texture_counter, vec2(xPos, 0.5));
        return pixels.r;
    }
    void main(void) {
        ivec4 oPos = getOutputTensorPos();

        int x = oPos.a;
        int c = oPos.g;
        int y = oPos.b;
        int b = oPos.r;
        int addAxis = oPos[`+f+`];
        float res = getValueFromCounter(addAxis);

        // 获取output的坐标
        int oTensorChannel = (c / (`+r.channel+" / "+u+")) * "+e.channel+`;
        int oy = y * `+V+" - "+A+`;
        for (int fy = 0; fy < `+e.height_shape+`; fy++) {
            if (oy >= `+o.height_shape+`) {
                break;
            }
            if (oy < 0) {
                oy += `+F+`;
                continue;
            }
            int ox = x * `+v+" - "+x+`;
            for (int fx = 0; fx < `+e.width_shape+`; fx++) {
                if (ox >= `+o.width_shape+`) {
                    break;
                }
                if (ox < 0) {
                    ox += `+O+`;
                    continue;
                }
                // channel计算
                for (int j = 0; j < `+e.channel+`; j++) {
                    float f = getValueFromTensorPos_filter(c, j, fy, fx);
                    float o = getValueFromTensorPos_origin(b, oTensorChannel + j, oy, ox);
                    res += f * o;
                }
                ox += `+O+`;
            }
            oy += `+F+`;
        }
        setOutput(`+i+"(res,  "+m+",  "+b+`));
    }
`},textureFuncConf:{filter:["getValueFromTensorPos"],origin:["getValueFromTensorPos"],counter:["getValueFromTensorPos"]},behaviors:["mergeAttrs","checkIsMerge","setActiveFunc"]},pool2d:{mainFunc:function(t,n){var o=t.origin,e=n.strides,r=e===void 0?[]:e,s=n.paddings,i=s===void 0?[]:s,a=n.pooling_type,u=n.ksize,f=r[0],l=f===void 0?1:f,c=r[1],g=c===void 0?1:c,d=i[0],_=d===void 0?0:d,h=i[1],m=h===void 0?0:h,b=u[0],P=u[1];return`
    // start函数
    void main(void) {
        float res = 0.0;
        if (`+a+` == 1) {
            res = -1.70141184e38;
        }
        // 获取output的坐标
        ivec4 out_pos = getOutputTensorPos();
        // X、Y方向的移动步长
        int count_pool = 0;
        int oy_base = out_pos[2] * `+l+" - "+_+`;
        int ox_base = out_pos[3] * `+g+" - "+m+`;
        for (int fy = 0; fy < `+b+`; fy++) {
            int oy = oy_base + fy;
            if (oy >= `+o.height_shape+`) {
                break;
            }
            if (oy < 0) {
                continue;
            }
            for (int fx = 0; fx < `+P+`; fx++) {
                int ox = ox_base + fx;
                if (ox >= `+o.width_shape+`) {
                    break;
                }
                if (ox < 0) {
                    continue;
                }
                // origin数据
                float curr = getValueFromTensorPos_origin(out_pos[0], out_pos[1], oy, ox);
                if (`+a+` == 1) {
                    if (curr > res) {
                        res = curr;
                    }
                } else {
                    res += curr;
                    // 在平均池化模式忽略填充值(exclusive默认为true）
                    count_pool++;
                }
            }
        }
        if (`+a+` != 1) {
            res = res / float(count_pool);
        }
        setOutput(res);
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"]},behaviors:["isMax","setPacked","setAdaptive","isGlobalPooling"]},pool2d_max:{mainFunc:function(t,n){var o=t.origin,e=n.strides,r=e===void 0?[]:e,s=n.paddings,i=s===void 0?[]:s,a=n.ksize,u=n.global_pooling,f=n.runtime,l=r[0],c=l===void 0?1:l,g=r[1],d=g===void 0?1:g,_=i[0],h=_===void 0?0:_,m=i[1],b=m===void 0?0:m,P=a[0],V=a[1],T=function(A){var p=A.total_shape,x=A.channel,y=A.height_shape,F=A.width_shape;return[p/x/y/F,x,y,F]}(o),v="",E="setOutput(float(res));";return f===0&&u===!0&&(v=`
            if (curr > res) {
                index = `+T[2]*T[3]+" * out_pos[1] + "+T[3]+` * oy + ox;
            }
        `,E="setOutput(float(index));"),`
    // start函数
    void main(void) {
        float res = -1.70141184e38;
        int index = 0;
        // 获取output的坐标
        ivec4 out_pos = getOutputTensorPos();
        int b = out_pos[0];
        int c = out_pos[1];
        int y = out_pos[2];
        int x = out_pos[3];
        // X、Y方向的移动步长
        int oy_base = out_pos[2] * `+c+" - "+h+`;
        int ox_base = out_pos[3] * `+d+" - "+b+`;
        for (int fy = 0; fy < `+P+`; fy++) {
            int oy = oy_base + fy;
            if (oy >= `+o.height_shape+`) {
                break;
            }
            if (oy < 0) {
                continue;
            }
            for (int fx = 0; fx < `+V+`; fx++) {
                int ox = ox_base + fx;
                if (ox >= `+o.width_shape+`) {
                    break;
                }
                if (ox < 0) {
                    continue;
                }
                // origin数据
                float curr = getValueFromTensorPos_origin(out_pos[0], out_pos[1], oy, ox);
                `+v+`
                res = max(res, curr);
            }
        }
        `+E+`
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"]},behaviors:["isMax","setPacked","setAdaptive","isGlobalPooling"]},pool2d_winograd:{mainFunc:function(t,n){var o=t.origin,e=t.pool,r=n.strides,s=r===void 0?[]:r,i=n.paddings,a=i===void 0?[]:i,u=n.type_pool,f=s[0],l=f===void 0?1:f,c=s[1],g=c===void 0?1:c,d=a[0],_=d===void 0?0:d,h=a[1],m=h===void 0?0:h,b=o.height_shape,P=o.width_texture,V=o.height_texture;return`

    float getValueFromTensorPosPacked_origin(int r, int g, int b, int a) {
        int y = b / 2;
        int yOffset = calMod(b, 2);
        int x = a / 2;
        int xOffset = calMod(a, 2);
        int height = `+b+" + "+o.offset_y+`;
        vec4 pixels = TEXTURE2D(
            texture_origin,
            vec2((float(x) + 0.5) / float(`+P+`),
            (float(g * height / 2 + y) + 0.5) / float(`+V+`))
        );
        int index = 0;
        if (xOffset == 0 && yOffset == 0) {
            return pixels[0];
        }
        else if (xOffset == 1 && yOffset == 0) {
            return pixels[1];
        }
        else if (xOffset == 0 && yOffset == 1) {
            return pixels[2];
        }
        return pixels[3];
    }

    // start函数
    void main(void) {
        float res = (-1.0 / exp(-20.0));
        // 获取output的坐标
        ivec4 out_pos = getOutputTensorPos();
        // int b = out_pos[0];
        // int c = out_pos[1];
        // int y = out_pos[2];
        // int x = out_pos[3];
        // X、Y方向的移动步长
        int count_pool = 0;
        int oy_base = out_pos[2] * `+l+" - "+_+`;
        int ox_base = out_pos[3] * `+g+" - "+m+`;

        for (int fy = 0; fy < `+e.height_shape+`; fy++) {
            int oy = oy_base + fy;
            if (oy >= `+o.height_shape+`) {
                break;
            }
            if (oy < 0) {
                continue;
            }
            for (int fx = 0; fx < `+e.width_shape+`; fx++) {
                int ox = ox_base + fx;
                if (ox >= `+o.width_shape+`) {
                    break;
                }
                if (ox < 0) {
                    continue;
                }
                // origin数据
                float curr = getValueFromTensorPosPacked_origin(out_pos[0], out_pos[1], oy, ox);
                if (`+u+` == 1) {
                    if (curr > res) {
                        res = curr;
                    }
                } else {
                    res += curr;
                    // 在平均池化模式忽略填充值(exclusive默认为true）
                    count_pool++;
                }
            }
        }
        if (`+u+` != 1) {
            res = res / float(count_pool);
        }
        setOutput(res);
    }
    `},behaviors:["isMax","setPacked","setAdaptive","isGlobalPooling"]},elementwise_add:{mainFunc:function(t,n){var o=n.counterPos,e=n.Scale_y,r=e===void 0?1:e,s=n.Scale_x,i=s===void 0?1:s,a=n.Scale_out,u=a===void 0?1:a;return`
    void main(void) {
        // 输出数据
        ivec4 oPos = getOutputTensorPos();
        float o = getValueFromTensorPos_origin(oPos.r, oPos.g, oPos.b, oPos.a);

        float c = getValueFromTensorPos_counter(`+o+`);
        float res = float(`+u/r+") * c + float("+u/i+`) * o;
        setOutput(float(res));
    }
    `},textureFuncConf:{counter:["getValueFromTensorPos"],origin:["getValueFromTensorPos"]},behaviors:["processElementwiseAxis","genElementwiseCounterPos"]},elementwise_mul:{mainFunc:function(t,n){var o=t.counter,e=n.counterPos,r=n.Scale_y,s=r===void 0?1:r,i=n.Scale_x,a=i===void 0?1:i,u=n.Scale_out,f=u===void 0?1:u;return`
    ivec4 formatNCHW(int n, int c, int h, int w) {
        int newN = n;
        int newC = c;
        int newH = h;
        int newW = w;

        if (n >= `+o.height_texture/o.height_shape+`) {
            newN = int(`+o.height_texture/o.height_shape+`);
        }
        if (c >= `+o.channel+`) {
            newC = int(`+(o.channel-1)+`);
        }
        if (h >= `+o.height_shape+`) {
            newH = `+(o.height_shape-1)+`;
        }
        if (w >= `+o.width_shape+`) {
            newW = `+(o.width_shape-1)+`;
        }
        return ivec4(newN, newC, newH, newW);
    }

    // start函数
    void main() {
        // 输出数据
        ivec4 oPos1 = getOutputTensorPos();
        float o = getValueFromTensorPos_origin(oPos1.r, oPos1.g, oPos1.b, oPos1.a);
        ivec4 oPos = formatNCHW(oPos1.r, oPos1.g, oPos1.b, oPos1.a);

        float c = getValueFromTensorPos_counter(`+e+`);
        float res = float(`+f/a+") * o * float("+1/s+`) * c;
        setOutput(float(res));
    }

    `},textureFuncConf:{counter:["getValueFromTensorPos"],origin:["getValueFromTensorPos"]},behaviors:["processElementwiseAxis","genElementwiseCounterPos"]},elementwise_div:{mainFunc:function(t,n){var o=t.counter,e=n.counterPos,r=n.Scale_y,s=r===void 0?1:r,i=n.Scale_x,a=i===void 0?1:i,u=n.Scale_out,f=u===void 0?1:u;return`
    ivec4 formatNCHW(int n, int c, int h, int w) {
        int newN = n;
        int newC = c;
        int newH = h;
        int newW = w;

        if (n >= `+o.height_texture/o.height_shape+`) {
            newN = int(`+o.height_texture/o.height_shape+`);
        }
        if (c >= `+o.channel+`) {
            newC = int(`+(o.channel-1)+`);
        }
        if (h >= `+o.height_shape+`) {
            newH = `+(o.height_shape-1)+`;
        }
        if (w >= `+o.width_shape+`) {
            newW = `+(o.width_shape-1)+`;
        }
        return ivec4(newN, newC, newH, newW);
    }

    // start函数
    void main() {
        // 输出数据
        ivec4 oPos1 = getOutputTensorPos();
        float o = getValueFromTensorPos_origin(oPos1.r, oPos1.g, oPos1.b, oPos1.a);
        ivec4 oPos = formatNCHW(oPos1.r, oPos1.g, oPos1.b, oPos1.a);

        float c = getValueFromTensorPos_counter(`+e+`);
        float res = float(`+f+") * (float("+1/a+") * o / (float("+1/s+`) * c));
        setOutput(float(res));
    }

    `},textureFuncConf:{counter:["getValueFromTensorPos"],origin:["getValueFromTensorPos"]},behaviors:["processElementwiseAxis","genElementwiseCounterPos"]},elementwise_pow:{mainFunc:function(t,n){var o=n.counterPos,e=n.Scale_y,r=e===void 0?1:e,s=n.Scale_x,i=s===void 0?1:s,a=n.Scale_out,u=a===void 0?1:a;return`
    void main(void) {
        // 输出数据
        ivec4 oPos = getOutputTensorPos();
        float o = getValueFromTensorPos_origin(oPos.r, oPos.g, oPos.b, oPos.a);

        float c = getValueFromTensorPos_counter(`+o+`);
        float res = pow(float(`+u/i+") * o, float("+u/r+`) * c);
        setOutput(float(res));
    }
    `},textureFuncConf:{counter:["getValueFromTensorPos"],origin:["getValueFromTensorPos"]},behaviors:["processElementwiseAxis","genElementwiseCounterPos"]},elementwise_sub:{mainFunc:function(t,n){var o=n.counterPos,e=n.Scale_y,r=e===void 0?1:e,s=n.Scale_x,i=s===void 0?1:s,a=n.Scale_out,u=a===void 0?1:a;return`
    void main(void) {
        // 输出数据
        ivec4 oPos = getOutputTensorPos();
        float o = getValueFromTensorPos_origin(oPos.r, oPos.g, oPos.b, oPos.a);

        float c = getValueFromTensorPos_counter(`+o+`);
        float res = float(`+u/i+") * o - float("+u/r+`) * c;
        setOutput(float(res));
    }
    `},textureFuncConf:{counter:["getValueFromTensorPos"],origin:["getValueFromTensorPos"]},behaviors:["processElementwiseAxis","genElementwiseCounterPos"]},mul:{mainFunc:function(t,n){var o=t.origin,e=t.counter,r=n.x_num_col_dims,s=n.y_num_col_dims,i=Dn(o),a=Dn(e),u=Mn(i,r),f=u[0],l=u[1],c=u[2],g=u[3],d=u[4],_=Mn(a,s),h=_[0],m=_[1],b=_[2],P=_[3];return`
    `+mn("x1",f,l)+`
    `+mn("x2",c,g)+`
    `+mn("y1",h,m)+`
    `+mn("y2",b,P)+`

    // start函数
    void main(void) {
        float res = 0.0;
        // 获取output的坐标
        ivec4 opos = getOutputTensorPos();
        float temp = 0.0;

        // output is 2D
        int b = opos.b;
        int a = opos.a;

        `+$(l)+` x1 = getTensorPosFromArrayIndex_x1(b);
        `+$(P)+` y2 = getTensorPosFromArrayIndex_y2(a);

        for (int j = 0; j < `+d[1]+`; j++) {
            `+$(g)+` x2 = getTensorPosFromArrayIndex_x2(j);
            `+$(m)+` y1 = getTensorPosFromArrayIndex_y1(j);

            ivec4 xPos = ivec4(`+$(l)+"(x1), "+$(g)+`(x2));
            ivec4 yPos = ivec4(`+$(m)+"(y1), "+$(P)+`(y2));

            float o = getValueFromTensorPos_origin(xPos.r, xPos.g, xPos.b, xPos.a);
            float c = getValueFromTensorPos_counter(yPos.r, yPos.g, yPos.b, yPos.a);
            res += c * o;
        }

        setOutput(res);
    }
    `},textureFuncConf:{counter:["getValueFromTensorPos"],origin:["getValueFromTensorPos"]}},matmul:Un,matmul_v2:Un,fc:{mainFunc:function(t,n){var o=t.origin,e=t.weight,r=n.x_num_col_dims,s=n.y_num_col_dims,i=jn(o),a=jn(e),u=Nn(i,r),f=u[0],l=u[1],c=u[2],g=u[3],d=u[4],_=Nn(a,s),h=_[0],m=_[1],b=_[2],P=_[3];return`
    `+Pn("x1",f,l)+`
    `+Pn("x2",c,g)+`
    `+Pn("y1",h,m)+`
    `+Pn("y2",b,P)+`

    // start函数
    void main(void) {
        float res = 0.0;
        // 获取output的坐标
        ivec4 opos = getOutputTensorPos();
        float bias = getValueFromTensorPos_bias(opos.r, opos.g, opos.b, opos.a);
        float temp = 0.0;

        // output is 2D
        int b = opos.b;
        int a = opos.a;

        `+J(l)+` x1 = getTensorPosFromArrayIndex_x1(b);
        `+J(P)+` y2 = getTensorPosFromArrayIndex_y2(a);

        for (int j = 0; j < `+d[1]+`; j++) {
            `+J(g)+` x2 = getTensorPosFromArrayIndex_x2(j);
            `+J(m)+` y1 = getTensorPosFromArrayIndex_y1(j);

            ivec4 xPos = ivec4(`+J(l)+"(x1), "+J(g)+`(x2));
            ivec4 yPos = ivec4(`+J(m)+"(y1), "+J(P)+`(y2));

            float o = getValueFromTensorPos_origin(xPos.r, xPos.g, xPos.b, xPos.a);
            float c = getValueFromTensorPos_weight(yPos.r, yPos.g, yPos.b, yPos.a);
            res += c * o;
        }

        res = res + bias;
        setOutput(res);
    }
    `},textureFuncConf:{weight:["getValueFromTensorPos"],origin:["getValueFromTensorPos"],bias:["getValueFromTensorPos"]}},dropout:{mainFunc:function(t,n){return`
    // start函数
    void main(void) {
        ivec4 oPos = getOutputTensorPos();
        // 输出坐标转换为输入坐标
        float o = 0.0;
        o = getValueFromTensorPos_origin(oPos.r, oPos.g, oPos.b, oPos.a);
        if (`+(n.dropout_implementation==="downgrade_in_infer")+`) {
            o = o * (1.0 - float(`+n.dropout_prob+`));
        }
        setOutput(float(o));
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"]}},concat:{mainFunc:function(t,n){var o=n.dim,e=Object.keys(t).filter(function(i){return i!=="out"}).map(function(i){return t[i]}).map(function(i){var a=i.width_shape,u=i.height_shape,f=i.channel;return[i.total_shape/(a*u*f),f,u,a][o]}),r=e.map(function(i,a){return e.slice(0,a+1).reduce(function(u,f){return u+f},0)}),s="";return r.forEach(function(i,a){s+=a===0?`
            if (oPos[`+o+"] < "+i+`) {
                o = getValueFromTensorPos_origin(oPos.r, oPos.g, oPos.b, oPos.a);
            }
            `:`
            else if (oPos[`+o+"] < "+i+`) {
                oPos[`+o+"] = oPos["+o+"] - "+r[a-1]+`;
                o = getValueFromTensorPos_origin_`+a+`(oPos.r, oPos.g, oPos.b, oPos.a);
            }
            `}),`
    // start函数
    void main(void) {
        ivec4 oPos = getOutputTensorPos();
        // 输出坐标转换为输入坐标
        float o = 0.0;
        `+s+`
        setOutput(float(o));
    }
    `},textureFuncConf:{"@all":["getValueFromTensorPos"]},behaviors:["normalizeDim"]},concat_mul:{mainFunc:function(t,n){var o=n.dim,e=Object.keys(t).filter(function(i){return i!=="out"}).map(function(i){return t[i]}).map(function(i){var a=i.width_shape,u=i.height_shape,f=i.channel;return[i.total_shape/(a*u*f),f,u,a][o]}),r=e.map(function(i,a){return e.slice(0,a+1).reduce(function(u,f){return u+f},0)}),s="";return r.forEach(function(i,a){s+=a===0?`
            if (oPos[`+o+"] < "+i+`) {
                o = getValueFromTensorPos_origin(oPos.r, oPos.g, oPos.b, oPos.a);
            }`:`
            else if (oPos[`+o+"] < "+i+`) {
                oPos[`+o+"] = oPos["+o+"] - "+r[a-1]+`;
                o = getValueFromTensorPos_origin_`+a+`(oPos.r, oPos.g, oPos.b, oPos.a);
            }
            `}),`
    // start函数
    void main(void) {
        ivec4 oPos = getOutputTensorPos();
        // 输出坐标转换为输入坐标
        float o = 0.0;
        `+s+`
        setOutput(float(o));
    }
    `},textureFuncConf:{"@all":["getValueFromTensorPos"]},behaviors:["normalizeDim"]},split:{mainFunc:function(t,n){var o=n.target_length,e=n.num,r=n.dim,s=n.sections;return`
    // start函数
    void main(void) {
        int length = int(`+(s&&s.length>1?s[0]:o/e)+`);
        ivec4 oPos = getOutputTensorPos();
        // 输出坐标转换为输入坐标
        oPos[`+r+"] = oPos["+r+`] + layer_run_time * length;
        float o = getValueFromTensorPos_origin(oPos.r, oPos.g, oPos.b, oPos.a);
        setOutput(float(o));
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"]},behaviors:["normalizeDim"]},softmax:{mainFunc:function(t,n){var o=t.origin,e=n.axis,r=e;return(!e||e<0)&&(r=(e||-1)+4),`
    // start函数
    void main(void) {
        ivec4 oPos = getOutputTensorPos();
        const int n = int(`+o.total_shape+"/"+o.channel+"/"+o.height_shape+"/"+o.width_shape+`);
        float o = getValueFromTensorPos_origin(oPos[0], oPos[1], oPos[2], oPos[3]);
        // 输出坐标转换为输入坐标
        float total = 0.0;
        float res = 0.0;
        if (`+r+` == 0) {
            for (int i = 0; i < n; i++){
            float temp = getValueFromTensorPos_origin(i, oPos[1], oPos[2], oPos[3]);
            total += exp(temp);
            }
            res = exp(o) / total;
        }
        else if (`+r+` == 1) {
            for (int i = 0; i < `+o.channel+`; i++){
            float temp = getValueFromTensorPos_origin(oPos[0], i, oPos[2], oPos[3]);
            total += exp(temp);
            }
            res = exp(o) / total;
        }
        else {
            for (int i = 0; i < `+o.width_shape+`; i++){
            float temp = getValueFromTensorPos_origin(oPos[0], oPos[1], oPos[2], i);
            total += exp(temp);
            }
            res = exp(o) / total;
        }
        setOutput(res);
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"]}},batchnorm:{mainFunc:function(t,n){var o=t.bias,e=t.scale,r=t.mean,s=t.variance,i=n.epsilon;return`
    // start函数
    void main(void) {
        // 输出数据
        ivec4 oPos = getOutputTensorPos();
        float o = getValueFromTensorPos_origin(oPos.r, oPos.g, oPos.b, oPos.a);

        // 归一化数据
        vec4 scale = getPixelsFromTexturePos_scale(vec2( float(oPos.g) / float(`+e.width_texture+`) + 0.00001, 0.0));
        vec4 bias = getPixelsFromTexturePos_bias(vec2( float(oPos.g) / float(`+o.width_texture+`) + 0.00001, 0.0));
        vec4 mean = getPixelsFromTexturePos_mean(vec2((float(oPos.g)) / float(`+r.width_texture+`)  + 0.00001, 0.0));
        vec4 variance = getPixelsFromTexturePos_variance(
            vec2((float(oPos.g)) / float(`+s.width_texture+`) + 0.00001,
            0.0)
        );

        float x = (o - mean[0]) / sqrt(variance[0] + `+i+`);
        float res = scale[0] * x + bias[0];
        setOutput(res);
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"],scale:["getPixelsFromTexturePos"],bias:["getPixelsFromTexturePos"],mean:["getPixelsFromTexturePos"],variance:["getPixelsFromTexturePos"]}},reshape:Vn,reshape2:Vn,bilinear_interp:Xn,transpose2:{mainFunc:function(t,n){var o=n.perm_arr,e=n.perm_size,r=o[0],s=o[1],i=o[2];return`
    // start函数
    void main(void) {
        // 输出数据
        ivec4 oPos = getOutputTensorPos();

        // 转置 坐标变换
        float o = 0.0;
        if (`+e+` == 1) {
            o = getValueFromTensorPos_origin(oPos[0], oPos[1], oPos[2], oPos[3]);
        }
        else if (`+e+` == 2) {
            o = getValueFromTensorPos_origin(
                oPos[0], oPos[1],
                oPos[(2 + `+r+") > 3 ? 3 : (2 + "+r+`)],
                oPos[(2 + `+s+") > 3 ? 3 : (2 + "+s+`)]
            );
        }
        else if (`+e+` == 3) {
            o = getValueFromTensorPos_origin(
                oPos[0],
                oPos[(1 + `+r+") > 3 ? 3 : (1 + "+r+`)],
                oPos[(1 + `+s+") > 3 ? 3 : (1 + "+s+`)],
                oPos[(1 + `+i+") > 3 ? 3 : (1 + "+i+`)]
            );
        }
        else if (`+e+` == 4) {
            o = getValueFromTensorPos_origin(
                oPos[`+r+`],
                oPos[`+s+`],
                oPos[`+i+`],
                oPos[`+o[3]+`]
            );
        }

        setOutput(float(o));
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"]},behaviors:["normalizePerm"]},unpacked_2_packed:{mainFunc:function(t,n){return`
    // start函数
    void main() {
        ivec4 oPos = getOutputTensorPos();
        vec4 out4;
        for (int i = 0; i < 4; i++) {
            vec4 o = getValueFromTensorPosPacking_origin(oPos[0], oPos[1] * 4 + i, oPos[2], oPos[3]);
            out4[i] = o[0];
        }
        setPackedOutput(out4);
    }
    `},textureFuncConf:{origin:["getValueFromTensorPosPacking"]}},packed_2_unpacked:{mainFunc:function(t,n){return`
    // start函数
    void main() {
        ivec4 oPos = getOutputTensorPos();
        float res = 0.0;
        int c1 = calMod(oPos[1], 4);
        vec4 o = getValueFromTensorPosPacking_origin(oPos[0], oPos[1] / 4, oPos[2], oPos[3]);

        if (c1 == 0) {
            res = o.r;
        } else if (c1 == 1) {
            res = o.g;
        } else if (c1 == 2) {
            res = o.b;
        } else if (c1 == 3) {
            res = o.a;
        }
        setOutput(res);
    }
    `},textureFuncConf:{origin:["getValueFromTensorPosPacking"]}},unsqueeze2:{mainFunc:function(t,n){var o=t.origin,e=n.axes,r=o.length_unformatted_shape,s=Array.isArray(e)?e:[e],i=4-r-s.length,a=s.map(function(l){return l+i}),u=[0,1,2,3].filter(function(l){return a.indexOf(l)===-1}).map(function(l){return"oPos["+l+"]"}),f=Array.from(new Array(a.length),function(){return"0"});return u.splice.apply(u,function(){for(var l=0,c=0,g=arguments.length;c<g;c++)l+=arguments[c].length;var d=Array(l),_=0;for(c=0;c<g;c++)for(var h=arguments[c],m=0,b=h.length;m<b;m++,_++)d[_]=h[m];return d}([0,0],f)),`
    void main() {
        ivec4 oPos = getOutputTensorPos();
        float o = 0.0;
        o = getValueFromTensorPos_origin(`+u.join(",")+`);
        setOutput(float(o));
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"]}},flatten_contiguous_range:{mainFunc:function(t,n){var o=t.origin,e=t.out;return`
    void main() {
        ivec4 oPos = getOutputTensorPos();
        // 输出坐标转换为输入坐标
        int sumVal = oPos.a
            + oPos.b * `+e.width_shape+`
            + oPos.g * `+e.height_shape+" * "+e.width_shape+`
            + oPos.r * `+e.channel+" * "+e.width_shape+" * "+e.height_shape+`;
        ivec4 new_oPos = transferFromNHWCtoNCHW(
            sumVal,
            `+o.channel+`,
            `+o.width_shape+`,
            `+o.height_shape+`,
            `+o.total_shape+`
        );
        float o = getValueFromTensorPos_origin(new_oPos.r, new_oPos.g, new_oPos.b, new_oPos.a);
        setOutput(float(o));
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"]},commonFuncConf:["transferFromNHWCtoNCHW"]},flatten2:Vn,greater_than:{mainFunc:function(t,n){return`
    // start函数
    void main(void) {
        ivec4 oPos = getOutputTensorPos();
        // 输出坐标转换为输入坐标
        float x = getValueFromTensorPos_input(oPos.r, oPos.g, oPos.b, oPos.a);
        float y = getValueFromTensorPos_counter(oPos.r, oPos.g, oPos.b, oPos.a);

        setOutput(bool(x >= y));
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"],counter:["getValueFromTensorPos"]}},reduce_sum:{mainFunc:function(t,n){return`
    // start函数
    void main(void) {
        ivec4 oPos = getOutputTensorPos();
        // 输出坐标转换为输入坐标
        float o = 0.0;
        for (int i = 0; i < `+n.inputs_dim+`; i++) {
            oPos[`+n.dim+`] = i;
            o += getValueFromTensorPos_origin(oPos.r, oPos.g, oPos.b, oPos.a);;
        }
        setOutput(float(o));
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"]},behaviors:["normalizeDim"]},where:{mainFunc:function(t,n){return`
    // start函数
    void main(void) {
        ivec4 oPos = getOutputTensorPos();
        // 输出坐标转换为输入坐标
        float x = getValueFromTensorPos_input(oPos.r, oPos.g, oPos.b, oPos.a);
        float y = getValueFromTensorPos_counter(oPos.r, oPos.g, oPos.b, oPos.a);
        float condition = getValueFromTensorPos_condition(oPos.r, oPos.g, oPos.b, oPos.a);
        float o = 0.0;

        if (bool(condition)) {
            o = x;
        }
        else {
            o = y;
        }
        setOutput(o);
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"],counter:["getValueFromTensorPos"],condition:["getValueFromTensorPos"]}},connect:{mainFunc:function(t,n){var o=t.out,e=o.total_shape,r=o.width_shape,s=o.height_shape,i=o.channel,a=fn([e/(r*s*i),i,s,r]),u=Object.keys(t).filter(function(c){return c!=="out"}).map(function(c){return t[c].total_shape}),f=u.map(function(c,g){return u.slice(0,g+1).reduce(function(d,_){return d+_},0)}),l="";return f.forEach(function(c,g){l+=g===0?`
            if (sumVal < `+c+`) {
                co = getTensorPosFromArrayIndex_origin(sumVal);
                o = getValueFromTensorPos_origin(co.r, co.g, co.b, co.a);
            }`:`
            else if (sumVal < `+c+`) {
                co = getTensorPosFromArrayIndex_origin_`+g+"(sumVal - "+f[g-1]+`);
                o = getValueFromTensorPos_origin_`+g+`(co.r, co.g, co.b, co.a);
            }
            `}),`
    // start函数
    void main(void) {
        ivec4 oPos = getOutputTensorPos();
        float o = 0.0;
        ivec4 co;
        int sumVal = oPos.b * `+a[2]+` + oPos.a;
        `+l+`
        setOutput(float(o));
    }
    `},textureFuncConf:{"@all":["getValueFromTensorPos","getTensorPosFromArrayIndex"]}},reduce_mean:{mainFunc:function(t,n){var o=n.inputs_dim;return`
    // start函数
    void main(void) {
        ivec4 oPos = getOutputTensorPos();
        // 输出坐标转换为输入坐标
        float o = 0.0;
        for (int i = 0; i < `+o+`; i++) {
            oPos[`+n.dim+`] = i;
            o += getValueFromTensorPos_origin(oPos.r, oPos.g, oPos.b, oPos.a);
        }
        o = o / float(`+o+`);
        setOutput(o);
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"]},behaviors:["normalizeDim"]},hard_swish:{mainFunc:function(t,n){var o=n.offset,e=o===void 0?3:o,r=n.scale,s=r===void 0?6:r,i=n.threshold;return`
    void main(void) {
        // 输出数据
        ivec4 oPos = getOutputTensorPos();
        float o = getValueFromTensorPos_origin(oPos.r, oPos.g, oPos.b, oPos.a);
        float res = o * min(max(0.0, o + float(`+e+")), float("+(i===void 0?6:i)+")) / float("+s+`);
        setOutput(res);
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"]}},nearest_interp:Gn,nearest_interp_v2:Gn,cast:{mainFunc:function(t,n){var o="";switch(n.out_dtype){case 0:o=`
            float res_bool = 0.0;
            if (o != 0.0) {
                res_bool = 1.0;
            }
            setOutput(res_bool);`;break;case 1:case 2:case 3:o=`
            int res_int = int(o);
            setOutput(float(res_int));`;break;default:o=`       
            float res_float = o;
            setOutput(res_float);`}return`
    void main() {
       // 输出数据
        ivec4 oPos = getOutputTensorPos();
        float o = getValueFromTensorPos_origin(oPos.r, oPos.g, oPos.b, oPos.a);
        `+o+`
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"]}},fill_constant_batch_size_like:{mainFunc:function(t,n){return`
    // start函数
    void main(void) {
        float res = float(`+n.value+`);
        setOutput(res);
    }
`}},rnn_matmul:{mainFunc:function(t,n){var o=t.weightlist_0,e=n.input_axis,r=n.state_axis,s=n.batch,i=n.reverse,a=i!==void 0&&i?s-e-1:e;return`
    void main() {
         float res = 0.0;
        // 获取output的坐标
        ivec4 out_pos = getOutputTensorPos();
        
        if (`+(e===0)+`) {
            res = getValueFromTensorPos_origin(out_pos[0], `+a+`, out_pos[2], out_pos[3]);
            setOutput(res);
            return;
        }
        
        ivec4 origin_pos = out_pos;
        ivec4 weight_pos = out_pos;

        weight_pos[1] = 0;
        weight_pos[2] = weight_pos[3];

        float o = 0.0;
        float w_hh = 0.0;
        float prestate_h = 0.0;
        res = getValueFromTensorPos_origin(out_pos[0], `+a+`, out_pos[2], out_pos[3]);
        for (int j = 0; j < `+o.width_shape+`; j++) {
            prestate_h = getValueFromTensorPos_prestate(origin_pos[0], origin_pos[1], origin_pos[2], j);
            w_hh = getValueFromTensorPos_weightlist_0(out_pos[0], `+r+`, out_pos[3], j);
            o += w_hh * prestate_h;
        }
        res += o;

        setOutput(res);
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"],prestate:["getValueFromTensorPos"],weightlist_0:["getValueFromTensorPos"]}},rnn_hidden:{mainFunc:function(t,n){var o=n.state_axis,e=n.hidden_size;return`
    // start函数
    void main(void) {
        ivec4 oPos = getOutputTensorPos();
        float origin = getValueFromTensorPos_origin(oPos.r, oPos.g, oPos.b, oPos.a);
        float cell = getValueFromTensorPos_origin(oPos.r, oPos.g, oPos.b, oPos.a + `+e+`);
        float appender = getValueFromTensorPos_origin(oPos.r, oPos.g, oPos.b, oPos.a + `+2*e+`);
        float fourth = getValueFromTensorPos_origin(oPos.r, oPos.g, oPos.b, oPos.a + `+3*e+`);
        float counter  = getValueFromTensorPos_counter(oPos.r, `+o+`, oPos.b, oPos.a);
        float i = 1.0 / (1.0 + exp(-origin));
        float f = 1.0 / (1.0 + exp(-cell));
        float o = 1.0 / (1.0 + exp(-fourth));
        float c = f * counter + i * tanh_calc(appender);
        float h = o * tanh_calc(c);
        
        setOutput(h);
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"],counter:["getValueFromTensorPos"]}},rnn_cell:{mainFunc:function(t,n){var o=n.state_axis,e=n.hidden_size;return`
    // start函数
    void main(void) {
        ivec4 oPos = getOutputTensorPos();
        float origin = getValueFromTensorPos_origin(oPos.r, oPos.g, oPos.b, oPos.a);
        float cell = getValueFromTensorPos_origin(oPos.r, oPos.g, oPos.b, oPos.a + `+e+`);
        float appender = getValueFromTensorPos_origin(oPos.r, oPos.g, oPos.b, oPos.a + `+2*e+`);
        float fourth = getValueFromTensorPos_origin(oPos.r, oPos.g, oPos.b, oPos.a + `+3*e+`);
        float counter  = getValueFromTensorPos_counter(oPos.r, `+o+`, oPos.b, oPos.a);
        float i = 1.0 / (1.0 + exp(-origin));
        float f = 1.0 / (1.0 + exp(-cell));
        float c = f * counter + i * tanh_calc(appender);
        
        setOutput(c);
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"],counter:["getValueFromTensorPos"]}},rnn_origin:{mainFunc:function(t,n){var o=t.weightlist_0,e=t.weightlist_1,r=n.state_axis;return`
    void main() {
        float res = 0.0;
        // 获取output的坐标
        ivec4 out_pos = getOutputTensorPos();
        ivec4 origin_pos = out_pos;
        ivec4 weight_pos = out_pos;
      
        weight_pos[1] = 0;
        weight_pos[2] = weight_pos[3];

        float b_ih = getValueFromTensorPos_weightlist_2(0, 0, 0, out_pos[3]);
        float b_hh = getValueFromTensorPos_weightlist_3(0, 0, 0, out_pos[3]);
        
        for (int j = 0; j < `+o.width_shape+`; j++) {
            float o = getValueFromTensorPos_origin(origin_pos[0], origin_pos[1], 0, j);
            float w_ih = getValueFromTensorPos_weightlist_0(0, 0, out_pos[3], j);
            res += w_ih * o;
        }
        res += b_ih;

        for (int j = 0; j < `+e.width_shape+`; j++) {
                float prestate = getValueFromTensorPos_prestate(0, 0, 0, j);
                float w_hh = getValueFromTensorPos_weightlist_1(0, `+r+`, out_pos[3], j);
                res += w_hh * prestate;
        }
        res += b_hh;
 
        setOutput(res);
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"],prestate:["getValueFromTensorPos"],weightlist_0:["getValueFromTensorPos"],weightlist_1:["getValueFromTensorPos"],weightlist_2:["getValueFromTensorPos"],weightlist_3:["getValueFromTensorPos"]}},pool2d_avg:{mainFunc:function(t,n){var o=t.origin,e=n.strides,r=e===void 0?[]:e,s=n.paddings,i=s===void 0?[]:s,a=n.ksize,u=r[0],f=u===void 0?1:u,l=r[1],c=l===void 0?1:l,g=i[0],d=g===void 0?0:g,_=i[1],h=_===void 0?0:_,m=a[0],b=a[1];return`
    // start函数
    void main(void) {
        float res = 0.0;
        // 获取output的坐标
        ivec4 out_pos = getOutputTensorPos();
        // X、Y方向的移动步长
        int oy_base = out_pos[2] * `+f+" - "+d+`;
        int ox_base = out_pos[3] * `+c+" - "+h+`;
        for (int fy = 0; fy < `+m+`; fy++) {
            int oy = oy_base + fy;
            if (oy >= `+o.height_shape+`) {
                break;
            }
            if (oy < 0) {
                continue;
            }
            for (int fx = 0; fx < `+b+`; fx++) {
                int ox = ox_base + fx;
                if (ox >= `+o.width_shape+`) {
                    break;
                }
                if (ox < 0) {
                    continue;
                }
                // origin数据
                float curr = getValueFromTensorPos_origin(out_pos[0], out_pos[1], oy, ox);
                res += curr;
                // 在平均池化模式忽略填充值(exclusive默认为true）
            }
        }
        res = res / float(`+m+" * "+b+`);
        setOutput(res);
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"]},behaviors:["setPacked","setAdaptive","isGlobalPooling"]},prelu:Y("prelu"),relu6:Y("relu6"),leakyRelu:Y("leakyRelu"),scale:Y("scale"),sigmoid:Y("sigmoid"),relu:Y("relu"),hard_sigmoid:Y("hard_sigmoid"),pow:Y("pow"),sqrt:Y("sqrt"),tanh:Y("tanh"),exp:Y("exp"),squeeze2:Fo,pad3d:{mainFunc:function(t,n){var o=t.origin,e=n.paddings,r=n.mode,s=n.value,i=function(u){var f=u.total_shape,l=u.channel,c=u.height_shape,g=u.width_shape;return[f/l/c/g,l,c,g]}(o),a={reflect:`
            int a;
            int b;
            if (oPos.a - `+e[0]+` < 0) {
                a = `+e[0]+` - oPos.a;
            }
            else if (oPos.a - `+e[0]+" >= "+i[3]+`) {
                a = `+i[3]+" - (oPos.a - "+e[0]+" - "+i[3]+` + 1) - 1;
            }
            else {
                a = oPos.a - `+e[0]+`;
            }
            if (oPos.b - `+e[2]+` < 0) {
                b = `+e[2]+` - oPos.b;
            }
            else if (oPos.b - `+e[2]+" >= "+i[2]+`) {
                b = `+i[2]+" - (oPos.b - "+e[2]+" - "+i[2]+` + 1) - 1;
            }
            else {
                b = oPos.b - `+e[2]+`;
            }
            o = getValueFromTensorPos_origin(oPos.r, oPos.g, b, a);
        `,replicate:`
            int a;
            int b;
            if (oPos.a - `+e[0]+` < 0) {
                a = 0;
            }
            else if (oPos.a - `+e[0]+" >= "+i[3]+`) {
                a = `+i[3]+` - 1;
            }
            else {
                a = oPos.a - `+e[0]+`;
            }
            if (oPos.b - `+e[2]+` < 0) {
                b = 0;
            }
            else if (oPos.b - `+e[2]+" >= "+i[2]+`) {
                b = `+i[2]+` - 1;
            }
            else {
                b = oPos.b - `+e[2]+`;
            }
            o = getValueFromTensorPos_origin(oPos.r, oPos.g, b, a);
        `,circular:`
            int a;
            int b;
            if (oPos.a - `+e[0]+` < 0) {
                a = int(mod(float(`+e[0]+" + oPos.a - 1), float("+i[3]+`)));
            }
            else if (oPos.a - `+e[0]+" >= "+i[3]+`) {
                a = int(mod(float(oPos.a - `+e[0]+" - "+i[3]+"), float("+i[3]+`)));
            }
            else {
                a = oPos.a - `+e[0]+`;
            }
            if (oPos.b - `+e[2]+` < 0) {
                b = int(mod(float(`+e[2]+" + oPos.b - 1), float("+i[2]+`)));
            }
            else if (oPos.b - `+e[2]+" >= "+i[2]+`) {
                b = int(mod(float(oPos.b - `+e[2]+" - "+i[2]+"), float("+i[2]+`)));
            }
            else {
                b = oPos.b - `+e[2]+`;
            }
            o = getValueFromTensorPos_origin(oPos.r, oPos.g, b, a);
        `,constant:"",undefined:""};return`
    // start函数
    void main(void) {
        ivec4 oPos = getOutputTensorPos();
        float o = `+(s||"0.0")+`;
        if (oPos.a - `+e[0]+` >= 0
            && oPos.b - `+e[2]+` >= 0
            && oPos.a - `+e[0]+" < "+i[3]+`
            && oPos.b - `+e[2]+" < "+i[2]+`
        ) {
            o = getValueFromTensorPos_origin(oPos.r, oPos.g, oPos.b - `+e[2]+", oPos.a - "+e[0]+`);
        }
        else {
            `+a[r]+`
        }
        setOutput(float(o));
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"]}},bilinear_interp_v2:vo,shuffle_channel:{mainFunc:function(t,n){var o=t.out,e=n.group,r=e===void 0?2:e,s=o.total_shape,i=o.height_shape,a=o.width_shape,u=o.channel,f=[1,0,2,3];return`
    // start函数
    void main(void) {
        // 输出数据
        ivec4 oPos = getOutputTensorPos();
        float o = 0.0;

        int sumVal = oPos.a
            + oPos.b * `+a+`
            + oPos.g * `+i+" * "+a+`
            + oPos.r * `+u+" * "+a+" * "+i+`;

        ivec4 transpose_out_pos = transferFromNHWCtoNCHW(
            sumVal,
            `+r+`,
            `+a+`,
            `+i+`,
            `+s+`
        );

        ivec4 transpose_in_pos = ivec4(transpose_out_pos[`+f[0]+`],
            transpose_out_pos[`+f[1]+"], transpose_out_pos["+f[2]+"], transpose_out_pos["+f[3]+`]);
        int sumVal2 = transpose_in_pos.a
            + transpose_in_pos.b * `+a+`
            + transpose_in_pos.g * `+i+" * "+a+`
            + transpose_in_pos.r * `+u/r+" * "+a+" * "+i+`;
        ivec4 origin_oPos = transferFromNHWCtoNCHW(
            sumVal2,
            `+u+`,
            `+a+`,
            `+i+`,
            `+s+`
        );


        o = getValueFromTensorPos_origin(
            origin_oPos[0],
            origin_oPos[1],
            origin_oPos[2],
            origin_oPos[3]
        );

        setOutput(float(o));
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"]},commonFuncConf:["transferFromNHWCtoNCHW"]},pack_out:{mainFunc:function(t,n){return`

    // start函数
    void main() {
        ivec4 oPos = getOutputTensorPos();
        vec2 outCoord = vCoord.xy * _2d_shape_texture_out;
        int index = int(outCoord.x) + int(outCoord.y) * int(`+t.out.width_texture+`);

        int first = index * 4;
        int sec = index * 4 + 1;
        int third = index * 4 + 2;
        int fourth = index * 4 + 3;

        ivec4 rPos = getTensorPosFromArrayIndex_origin(first);
        ivec4 gPos = getTensorPosFromArrayIndex_origin(sec);
        ivec4 bPos = getTensorPosFromArrayIndex_origin(third);
        ivec4 aPos = getTensorPosFromArrayIndex_origin(fourth);

        float r = getValueFromTensorPos_origin(rPos.r, rPos.g, rPos.b, rPos.a);
        float g = getValueFromTensorPos_origin(gPos.r, gPos.g, gPos.b, gPos.a);
        float b = getValueFromTensorPos_origin(bPos.r, bPos.g, bPos.b, bPos.a);
        float a = getValueFromTensorPos_origin(aPos.r, aPos.g, aPos.b, aPos.a);

        setPackedOutput(vec4(r, g, b, a));
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos","getTensorPosFromArrayIndex"]}},nhwc_2_nchw:{mainFunc:function(t,n){var o=t.origin,e=t.out;return`
    void main() {
        ivec4 oPos = getOutputTensorPos();
        // 输出坐标转换为输入坐标
        int sumVal = oPos.a * `+e.channel+`
            + oPos.b * `+e.width_shape+" * "+e.channel+`
            + oPos.g
            + oPos.r * `+e.channel+" * "+e.width_shape+" * "+e.height_shape+`;
        ivec4 new_oPos = transferFromNHWCtoNCHW(
            sumVal,
            `+o.channel+`,
            `+o.width_shape+`,
            `+o.height_shape+`,
            `+o.total_shape+`
        );
        float o = getValueFromTensorPos_origin(new_oPos.r, new_oPos.g, new_oPos.b, new_oPos.a);
        setOutput(float(o));
    }
    `},textureFuncConf:{origin:["getValueFromTensorPos"]},commonFuncConf:["transferFromNHWCtoNCHW"]},feedPost:{mainFunc:function(t,n){var o=t.out,e=n.mean,r=e===void 0?[0,0,0]:e,s=n.std,i=s===void 0?[1,1,1]:s,a=o.total_shape,u=o.height_shape,f=o.width_shape,l=o.channel;return`
    // start函数
    void main(void) {
        ivec4 nhwcPos = getOutputTensorPos();
        int sumVal = nhwcPos.a
            + nhwcPos.b * `+f+`
            + nhwcPos.g * `+u+" * "+f+`
            + nhwcPos.r * `+l+" * "+f+" * "+u+`;

        ivec4 oPos = transferFromNHWCtoNCHW(
            sumVal,
            `+l+`,
            `+f+`,
            `+u+`,
            `+a+`
        );
        float res = 0.0;
        int c1 = int(mod(float(oPos[1]), 4.0));
        int c = oPos[1];
        vec4 o = getValueFromTensorPosPacking_origin(oPos[0], c / 4, oPos[2], oPos[3]);

        if (c1 == 0) {
            res = o.r;
        } else if (c1 == 1) {
            res = o.g;
        } else if (c1 == 2) {
            res = o.b;
        } else if (c1 == 3) {
            res = o.a;
        }

        if (c == 0) {
            res = (res - float(`+r[0]+")) / float("+i[0]+`);
        } else if (c == 1) {
            res = (res - float(`+r[1]+")) / float("+i[1]+`);
        } else if (c == 2) {
            res = (res - float(`+r[2]+")) / float("+i[2]+`);
        }
        setOutput(float(res));
    }
    `},textureFuncConf:{origin:["getValueFromTensorPosPacking"]},commonFuncConf:["transferFromNHWCtoNCHW"]},imgFeed:{mainFunc:function(){return`
    uniform vec2 u_scale;
    uniform int u_keep_ratio;

    void main(void) {
        vec2 outCoord = vCoord.xy;
        // 支持模型不按比例拉伸
        if (u_keep_ratio == 0) {
            vec4 origin = TEXTURE2D(texture_origin, outCoord);
            setPackedOutput(origin);
            return;
        }
        float startX = (1.0 - u_scale.x) / 2.0;
        float endX = startX + u_scale.x;
        float startY = (1.0 - u_scale.y) / 2.0;
        float endY = startY + u_scale.y;

        if (outCoord.x >= startX && outCoord.x <= endX && outCoord.y >= startY && outCoord.y <= endY) {
            vec2 newPos = (outCoord - vec2(startX, startY)) / u_scale;
            vec4 origin = TEXTURE2D(texture_origin, newPos);
            setPackedOutput(origin);
        }
        else {
            setPackedOutput(vec4(1.0));
        }
    }
    `},textureFuncConf:{origin:[]}},box_coder:{mainFunc:function(t,n){var o=n.code_type==="decode_center_size";return`
    // start函数
    vec2 getPriorBoxData(int r, int g, int b, int m, int n) {
        float start = getValueFromTensorPos_priorbox(r, g, b, m);
        float end = getValueFromTensorPos_priorbox(r, g, b, n);
        float len = end - start;
        return vec2(start + len / 2.0, len);
    }
    vec2 getBoxVarData(int r, int g, int b, int m, int n) {
        return vec2(
            getValueFromTensorPos_priorboxvar(r, g, b, m),
            getValueFromTensorPos_priorboxvar(r, g, b, n)
        );
    }
    vec2 getTargetBoxData(int r, int g, int b, int m, int n) {
        `+(o?`
            return vec2(
                getValueFromTensorPos_targetbox(r, g, b, m),
                getValueFromTensorPos_targetbox(r, g, b, n)
            );
        `:`
            float start = getValueFromTensorPos_targetbox(r, g, b, m);
            float end = getValueFromTensorPos_targetbox(r, g, b, n);
            float len = end - start;
            return vec2(start + len / 2.0, len);
        `)+`
    }

    void main(void) {
        ivec4 oPos = getOutputTensorPos();
        int r = int(oPos.r);
        int g = int(oPos.g);
        int b = int(oPos.b);
        int a = int(oPos.a);
        // 输出坐标转换为输入坐标
        float o = 0.0;

        int m = 0;
        int n = 0;
        if (a == 0 || a == `+(o?2:1)+`) {
            m = 0;
            n = 2;
        }
        else {
            m = 1;
            n = 3;
        }
        vec2 priorbox = getPriorBoxData(r, g, b, m, n);
        vec2 boxvar = getBoxVarData(r, g, b, m, n);
        vec2 targetbox = getTargetBoxData(r, g, b, m, n);
        float p1 = priorbox.r;
        float p2 = priorbox.g;
        float t1 = targetbox.r;
        float t2 = targetbox.g;
        float v1 = boxvar.r;
        float v2 = boxvar.g;

        `+(o?`
            float b1 = p2 * v1 * t1 + p1;
            float b2 = exp(v2 * t2) * p2;
            if (a == 0 || a == 1) {
                o = b1 - b2 / 2.0 ;
            }
            else {
                o = b1 + b2 / 2.0;
            }
        `:`
            if (a == 0 || a == 1) {
                o = (t1 - p1) / p2 / v1;
            }
            else {
                o = log(abs(t2 / p2)) / v2;
            }
        `)+`
        setOutput(float(o));
    }
    `},textureFuncConf:{targetbox:["getValueFromTensorPos"],priorbox:["getValueFromTensorPos"],priorboxvar:["getValueFromTensorPos"]},behaviors:[]},density_prior_box:yo,prior_box:Eo,stack:wo,slice:Vo},Wn=new Po;(function(t,n,o){t&&(en.backend=t),n&&(en.backendInstance=n),o&&Object.keys(o).forEach(function(e){(function(r,s){var i=r.conf,a=r.params,u=r.main,f=r.mainFunc,l=r.textureFuncConf,c=r.commonFuncConf,g=r.behaviors,d=g===void 0?[]:g,_=en.backend+"_"+s;en.opRegistry.ops[_]||(en.opRegistry.ops[_]={name:s,conf:i,params:a,main:u,mainFunc:f,textureFuncConf:l,commonFuncConf:c,behaviors:d})})(o[e],e)})})("webgl",Wn,Hn)}},z={};function U(M){if(z[M])return z[M].exports;var H=z[M]={exports:{}};return rn[M](H,H.exports,U),H.exports}return U.d=(M,H)=>{for(var D in H)U.o(H,D)&&!U.o(M,D)&&Object.defineProperty(M,D,{enumerable:!0,get:H[D]})},U.g=function(){if(typeof globalThis=="object")return globalThis;try{return this||new Function("return this")()}catch{if(typeof window=="object")return window}}(),U.o=(M,H)=>Object.prototype.hasOwnProperty.call(M,H),U.r=M=>{typeof Symbol<"u"&&Symbol.toStringTag&&Object.defineProperty(M,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(M,"__esModule",{value:!0})},U(400)})()})})(Lo);const ko=Ro(vn),Mo=Io({__proto__:null,default:ko},[vn]);export{Mo as i};
